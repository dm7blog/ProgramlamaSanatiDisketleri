#include <scr.h>
#include <stdio.h>
#include <colorscr.h>

extern CHR far*_screen;
typedef struct _WND {
	_byte flag,			/* 0 bo� / 1 dolu pencere 					*/
		  mode;			/* 0 a��k / 1 kapal� pencere  				*/
	CHR  *buf;			/* Arkadaki bilginin sakland��� tampon alan	*/
	_byte r1,c1,r2,c2;	/* Pencerenin koordinatlar�					*/
	} WND;

WND _wnd[MAXWNDNUM];	/* Pencere bilgilerinin sakland��� dizi     */

void wnd_free(int wno);
void wnd_change(int);
int wnd_set(int r1,int c1,int r2,int c2,int atr);

/************************************************************************
 *					wnd_set                                             *
 *  [c1,r1] sol �st,[c2,r2] sa� alt k��e koordinatlar� olan bir pencere *
 * a�ar.  															    *
 *  Arkadaki pencere bilgisini  WND yap�s�n�n "buf" alan�na aktar�r.    *
 *	Ekran�n [c1,r1],[c2,r2] 'nin s�n�rlad��� b�lgesini bo�luk karakteri *
 * ile doldurur.                                                        *
 *  Geri d�n�� de�eri i�lem ba�ar�l� ise _wnd'nin indeksi, de�ilse -1   *
 ************************************************************************/
int wnd_set(int r1,int c1,int r2,int c2,int atr)
{
	CHR far *p,
		far *t,
			*s;
	int i,j,k;

	for (i = 0;i < MAXWNDNUM; ++i)
		if (_wnd[i].flag == 0) break;
	if (i == MAXWNDNUM) return FAIL;

	j = (r2 - r1 + 1) * (c2 - c1 + 1);

	if ((_wnd[i].buf =(CHR  *)malloc(j * sizeof(CHR))) == NULL)
		return FAIL;

	_wnd[i].r1 = r1, _wnd[i].c1 = c1, _wnd[i].r2 = r2, _wnd[i].c2 = c2;

	p = (CHR far*)_screen;
	p += r1 * 80 + c1;
	t = p;
	s = _wnd[i].buf;
	while (r1++ <= r2) {
		k = c1;
		while (k++ <= c2) {
			*s++ = *t;
			t->chr = ' ';
			t++->attr = atr;
			}
		t = (p += 80);
		}
	frame(_wnd[i].r1,c1,r2,c2,white_|black);
	_wnd[i].flag = 1;
	_wnd[i].mode = W_OPN;
	return i;
	}
/************************************************************************
 *					wnd_change                                          *
 *  wno numaral� pencerenin "mode" alan�n� de�i�tirir  					*
 *  Arkadaki pencere bilgisini ekrana geri basar,ekrandaki bilgiyi      *
 *	buf alan�na aktar�r. 												*
 ************************************************************************/
void wnd_change(int wno)
{
	int i,k,r1,c1,r2,c2;
	CHR far *p,
		far *t,
			*s,
			temp;

	i = wno;
	r1 =_wnd[i].r1, c1 =_wnd[i].c1, r2 = _wnd[i].r2, c2 = _wnd[i].c2;

	p = (CHR far*)_screen;
	p += r1 * 80 + c1;
	t = p;
	s = _wnd[i].buf;
	while (r1++ <= r2) {
		k = c1;
		while (k++ <= c2) {
			temp = *t;
			*t++ = *s;
			*s++ = temp;
			}
		t = (p += 80);
		}
	_wnd[i].mode = (_wnd[i].mode == W_OPN) ? W_CLS : W_OPN;
}
/************************************************************************
 *					wnd_free	                                        *
 *  Pencereyi kapat�r,"buf" alan�n kaplad��� belle�i bo� hale getirir.	*
 ************************************************************************/
void wnd_free(int wno)
{
	if (_wnd[wno].flag == 0) return;
	if (_wnd[wno].mode == W_OPN)
		wnd_change(wno);
	free(_wnd[wno].buf);
	_wnd[wno].flag = 0;
}







