#define GLB_VAR

#include <scr.h>
#include <stdio.h>
#include <stdlib.h>
#include <dos.h>
#include <colorscr.h>



#define set_scrp	scrp += row * 80 + col;


/*typedef unsigned char _byte;
typedef unsigned int  _word;
typedef unsigned long _dword;*/

/*typedef struct _CHR {
	char chr,
	     attr;
	} CHR;*/

CHR far *_screen = (CHR far *)0XB8000000L;

void initvideo(void)
{
	union REGS iregs;
	_word c;

	int86(0X11,&iregs,&iregs);
	c = iregs.x.ax;

	if ((c & 0X30) == 0X30)
		 _screen = (CHR far *)0XB0000000L;
	else _screen = (CHR far *)0XB8000000L;

}

void writec(int row,int col,int ch,int attr)
{
	CHR far *scrp = (CHR far *)_screen;

	set_scrp

	scrp->chr = ch;
	scrp->attr = attr;
}
void chratr(int row,int col,int atr)
{
	CHR far *scrp = (CHR far *)_screen;

	set_scrp

	scrp->attr = atr;
}

void writes(int row,int col,char *str,int attr)
{
	CHR far *scrp = (CHR far *)_screen;

	scrp += row * 80 + col;

	while (*str) {
		scrp->chr = *str++;
		scrp++->attr = attr;
		}
}

void vfillch(int row,int col,int ch,int num,int atr)
{
	CHR far *scrp = _screen;

	set_scrp
	while (num-- > 0) {
		scrp->chr = ch;
		scrp->attr = atr;
		scrp += 80;
		}
}


void fillc(int row,int col,int chr,int num,int atr)
{
	while (num-- > 0)
		writec(row,col++,chr,atr);
}
void setatr(int row,int col,int atr,int num)
{
	while (num-- > 0)
		chratr(row,col++,atr);
}

void frame(int r1,int c1,int r2,int c2,int atr)
{

	writec(r2,c1,c_ll,atr);
	writec(r1,c1,c_ul,atr);
	writec(r1,c2,c_ur,atr);
	writec(r2,c2,c_lr,atr);

	fillc(r1,c1+1,c_h,c2 - c1 - 1,atr);
	fillc(r2,c1+1,c_h,c2 - c1 - 1,atr);

	vfillch(r1+1,c1,c_v,r2 - r1 - 1,atr);
	vfillch(r1+1,c2,c_v,r2 - r1 - 1,atr);
}




