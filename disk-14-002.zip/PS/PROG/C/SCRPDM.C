#include <scr.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <colorscr.h>
#include <dos.h>
typedef struct {
	_byte row,col,	/* Pulldown menun�n (PDM) sol �st k��esi */
		  cps,		/* Farkl� yaz�lacak sat�r�n numaras�     */
		  num,		/* PDM'deki eleman say�s�				 */
		  len;		/* En uzun sat�r�n uzunlu�u				 */
	char  wnd;		/* PDM'nin a��lan ka��nc� pencere oldu�u */
	char **menu;	/* PDM'nin i�eri�i						 */
	char idx[NROWS];/* Farkl� yaz�lacak harfin numaras�		 */
	}PDM;
char *menu0[] = {
		"&Ka�",
		"&Kekova",
		"&Saroz K�rfezi",
		NULL
	};
char *menu1[] = {
	"&C ve Sistem Programc�lar� Derne�i",
	"ATLAS Dergisi",
	NULL
	};

void select_item(PDM *pdm,int mode);
PDM * pdm_set(int row,int col,char **menu);
int pdm_get(PDM *pdm);
void pdm_free(PDM *pdm);

int getkb(void)
{
	union REGS iregs;

	iregs.h.ah = 0;
	int86(0x16,&iregs,&iregs);

	return iregs.x.ax;

}

/*************************************************************************
*					pdm_set                                              *
*  [col,row], sol �st k��esi olan bir PDM olu�turur.                     *
*  Sa� alt k��e, PDM'nin eleman say�s�, en uzun sat�r, farkl� yaz�lacak  *
* harfin konumu "menu" parametresi arac�l��� ile bulunur.                *
*  '&' karakteri, farkl� yaz�lmak istenen karakteri belirler.            *
*  Geri d�n�� de�eri, i�lem ba�ar�l� ise a��lan PDM, de�ilse NULL.       *
*************************************************************************/
PDM * pdm_set(int row,int col,char **menu)
{
	PDM *pdm;
	char *ptr;
	register i,j;
	int ch,
		maxlen,
		len;

	if ((pdm = (PDM *)calloc(1,sizeof(PDM))) == NULL) {
		return NULL;
		}
	pdm->row = row, pdm->col = col;
	pdm->menu = menu;
	pdm->cps = row;

	for (i = 0, maxlen = 0; i < NROWS && menu[i] != NULL; i++) {
		pdm->idx[i] = '\xFF';
		ptr = menu[i];
		len = 0;
		for (j = 0; ; ++j) {
			ch = *ptr++;
			if (ch == '\x0') break;
			if (ch == '&') pdm->idx[i] = j;
			else ++len;
			}
		if (len > maxlen) maxlen = len;
		}

	pdm->len = maxlen + 2;
	pdm->num = i;
	pdm->wnd = wnd_set(row - 1,col - 2,row + i,col + maxlen + 1,white_);
	if (pdm->wnd == FAIL)
		return NULL;
	while (--i >= 0) {
		j = col;
		ptr = menu[i];
		while (*ptr) {
			ch = *ptr++;
			if (ch != '&')
				writec(row + i,j++,ch,black | white_);
			}
		chratr(row + i,col + pdm->idx[i],red |white_);
		}
	select_item(pdm,1);
	return pdm;
}
/************************************************************************
*				select_item                                             *
*  "pdm->cps" sat�r�n�n renklerini de�i�tirir.                          *
*  "mode" parametresi 0 ise sat�r� ilk haline getirir, 1 ise sat�r      *
* se�ilmi�tir,arka plan renklerini de�i�tirir.                          *
*************************************************************************/
void select_item(PDM *pdm,int mode)
{
	int i;

	setatr(pdm->cps,pdm->col - 1,mode ? bold|white|black_ : black|white_,pdm->len);
	i = pdm->idx[pdm->cps - pdm->row];
	if (mode == 0)
		chratr(pdm->cps,pdm->col + i,red | white_);
}

/***************************************************************************
*					pdm_get												   *
*  Kullan�c�n�n se�imini alan fonksiyon.								   *
*                                                                          *
****************************************************************************/
int pdm_get(PDM *pdm)
{
	register n,len;
	int i,j,c,
		row,col,
		up,down,
		ret;
	char k;

	len = pdm->len;
	row = pdm->row, col = pdm->col;
	while (1) {
		up = (pdm->cps > row);
		down = (pdm->cps < row + pdm->num - 1);
		n = getkb();
		c = (char)n;
		c = toupper(c);
		for (i = 0;i < pdm->num;++i) {

			j = pdm->idx[i];

			if (j != -1) {
				k = pdm->menu[i][j + 1];
				k = toupper(k);
				}

			if (c == k) {
				select_item(pdm,0);
				pdm->cps = row + i;
				select_item(pdm,1);
				}
			} /*for*/

	switch (n) {

		case KP8 :
			select_item(pdm,0);
			if (up) --pdm->cps;
			else pdm->cps = row + pdm->num - 1;
			select_item(pdm,1);
			break;
		case KP2:
			select_item(pdm,0);
			if (down) ++pdm->cps;
			else pdm->cps = row;
			select_item(pdm,1);
			break;
		case CR:
			return pdm->cps - row;
		default :
			return n;
		}
	}
}
/**************************************************
* 				pdm_free                          *
*  PDM'nin kulland��� belle�i bo� hale getirir.   *
**************************************************/
void pdm_free(PDM *pdm)
{
	wnd_free(pdm->wnd);
	free(pdm);
}



main()
{
	PDM *pdm;
	int j;
	int sideways = 0;


	initvideo();
	setatr(0,0,white_|black,80);
	pdm = pdm_set(1,2,menu0);
	while (1) {
	j = pdm_get(pdm);
	   switch(j) {
	   case Esc:
			pdm_free(pdm);
			return;
	/* deneme arac� ile yaz�ld�, optimize edilebilir. */
		case KP6:
			pdm_free(pdm);
			sideways = (sideways + 1) % 2;
			if (sideways == 1) {
				pdm = pdm_set(2,10,menu1);
				}
			else {
				pdm = pdm_set(2,2,menu0);
				}
			break;

		case KP2:
			break;
		}

	}

}
