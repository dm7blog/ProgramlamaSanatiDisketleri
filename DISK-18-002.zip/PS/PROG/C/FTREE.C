				/*
				Bu program C ve Sistem Programc�lar� Derne�i'nin
				a�m�� oldu�u 'Sistem Programlamaya Giri�ve �leri C' kursunda
				G�rb�z Aslan taraf�ndan anlat�lm��t�r.	*/
				/*      Typing ve Yorum:Deniz �mit Kabuli       */

# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <dos.h>
# include <dir.h>

void _file_ (char *fname);
int ftree (char path[]);
unsigned _nfiles=0, _ndirs = 0 ;

void main(int argc, char *argv[])
{
	if(argc != 2)
	{
		fprintf(stderr,"Kullan�m:  ftree <path>\n");
		exit (1);
	}
	ftree(argv[1]);
	_file_(" ");
	printf("Dosya Say�s�: %u\nDizin say�s�: %u\n", _nfiles , _ndirs);

	exit (0);
}
int ftree(char path[])
{
	int ret=0;
	char *p, *cpath, *pbuf;
	static char _path[128], _fname [128];   /*static olmas� �nemli! */
	struct ffblk  *f_inf;   /*      haz�r yap�(dir.h'da bildirilmi�) */
	if(( f_inf=(struct ffblk *) malloc (sizeof(struct ffblk)))==NULL \
		||(cpath=malloc(128))==NULL ||(pbuf=malloc(128))==NULL)
			return -1;
			/*Dinamik bellek ay�rma i�lemi ba�ar�s�z ise -1'e return eder   */
	strcpy(cpath,path);
	strupr(cpath);       /* B�y�k harfe d�n��t�r�r  */
	p=strchr(cpath,'\0');
		if(p[1] != '\\'){
			*p ='\\';   /*  E�er yoksa cpath'in sonuna '\' ekler. */
		 *++p = '\0';
		}
	strcpy(_path,cpath);
	strcpy(p,"*.*");
	ret = findfirst(cpath,f_inf,FA_ARCH | FA_HIDDEN | FA_SYSTEM | FA_RDONLY);
		if(ret) /*      hi�bir t�rden(dizin hari�) dosya bulunmam�� ise */
		goto SRC_DIR;
	do {
		strcpy(_fname,_path);
		strcat(_fname,f_inf->ff_name);  /*yeni dosya ad�n� yola ekler   */
		_file_ (_fname);        /*      yazd�rma fonkiyonu �a�r�s�      */
		++_nfiles;        /*dosya sayac�*/
		} while(!findnext(f_inf));      /*tekrar arama*/
	SRC_DIR:
	/*	dizin arast�rma	*/
	ret = findfirst(cpath,f_inf,FA_ARCH | FA_HIDDEN | FA_SYSTEM |
	FA_RDONLY | FA_DIREC);
	if(ret)   goto EXIT;
	do {
			if(f_inf->ff_attrib & FA_DIREC){        /*Dosya t�r� dizin ise  */
				if(*f_inf->ff_name != '.') {    /*  "."ve ".."adl� �zel
												 dizinlerin kontrol�     */
					strcpy(pbuf,cpath);
					p = strchr(pbuf,'*');
					strcpy(p,f_inf->ff_name);       /*Yeni dizin ad� yola
														 ekleniyor       */
					++_ndirs;                     /*        dizin sayac�    */
					ftree(pbuf);    		 /* fonksiyon kendini �a��r�yor*/
				}
			}
		} while(!findnext(f_inf));
		EXIT:
		/* Bellek yetersizli�ini �nlemek i�in bellek bo�altma yap�l�yor  */
		free(f_inf);
		free(cpath);
		free(pbuf);
		return ret;
	}

	void _file_ (char *fname)
	{
		static int olen = 0;
		int i,len;
		len = strlen(fname);
		printf("%s",fname);
		i = olen - len;
		while (i-->0)
			putchar(' ');  /*Bir �nce yaz�lm�� fazla karakterler silinyor   */
		putchar('\r');
		olen = len;
	}
