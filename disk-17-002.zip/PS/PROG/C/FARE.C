#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <dos.h>

union REGS inregs,outregs;
struct SREGS segregs;
int iks,ye,dugme;

void acfare(void) // Fareyi ilk kullan�ma haz�rlar. (Fare a� de�ildir, ben faremi iyi beslerim)
{
  inregs.x.ax = 0;
  int86x(0x33, &inregs, &outregs, &segregs);
  if (outregs.x.ax==0) {printf("Fare yok.");exit(1);}
}

void gosterfare(void) // Farenin g�stergecini ekranda g�z�k�r duruma getirmek i�in. (Farem te�hirci hi� de�ildir)
{
  inregs.x.ax = 1;
  int86x(0x33, &inregs, &outregs, &segregs);
}

void saklafare(void) // Farenin g�stergecini ekrandan yoketmek icin. (Faremin asl�nda gizlisi sakl�s� yoktur)
{
  inregs.x.ax = 2;
  int86x(0x33, &inregs, &outregs, &segregs);
}

int okufare(int *x,int *y,int *button) // Fare s�r�c�s�n�n fare hakk�nda g�nderdi�i bilgileri almak i�in. (Benim farem k�lt�rl�d�r, okuma yazmas� bile var)
/* Gelen paremetreler farenin ekrandaki x,y kordinatlar� ve farenin o anki
  bas�l� bulunan tu� bilgisi. Tu� bilgisi bit-kodlanm��t�r.
  00000000
       |||_ sol tu� bas�ld�ysa 1 olur
       ||__ sag tu� bas�ld�ysa 1 olur
       |___ orta tu� bas�ld�ysa 1 olur
  Yani hi�bir tu� bas�l� de�ilse 0, sol bas�l�ysa 1, sa� bas�l�ysa 2, hem sol
  hem sa� bas�l�ysa 3 , vs. vs. �eklinde de�er al�r button de�i�keni.
*/
{
  inregs.x.ax = 3;
  int86x(0x33, &inregs, &outregs, &segregs);
  *x=(int)outregs.x.cx;
  *y=(int)outregs.x.dx;
  *button=(int)outregs.x.bx;
  return *button;
}

void koyfare(int x, int y) // Farenin g�stergecini ekranda konumland�rmak i�in. (Benim farem asl�nda �ok terbiyelidir)
{
  inregs.x.ax = 4;
  inregs.x.cx = (unsigned)x;
  inregs.x.dx = (unsigned)y;
  int86x(0x33, &inregs, &outregs, &segregs);
}

void sinirlafare(int x1, int y1,int x2,int y2) // G�stergecin dola�abilece�i alan� s�n�rland�rmak i�in (Benim farem s�n�r tan�maz)
  {
  inregs.x.ax = 7;
  inregs.x.cx = (unsigned)x1;
  inregs.x.dx = (unsigned)x2;
  int86x(0x33, &inregs, &outregs, &segregs);
  inregs.x.ax = 8;
  inregs.x.cx = (unsigned)y1;
  inregs.x.dx = (unsigned)y2;
  int86x(0x33, &inregs, &outregs, &segregs);
  }

void main(void)
{
 acfare(); // fare a��l�r
 gosterfare(); // fare g�sterilir (text modunda)
 do {
    okufare(&iks,&ye,&dugme); // veriler al�n�r
    gotoxy(1,1);printf("x:%3d",iks);gotoxy(7,1);printf("y:%3d",ye); // ekrana yaz�l�r
    gotoxy(13,1);
     switch(dugme) {                     // tu� durumu saptan�r
	case 0: printf("Bos    ");break; // ekrana yaz�l�r
	case 1: printf("Sol    ");break;
	case 2: printf("Sag    ");break;
	case 3: printf("Sol+Sag");break;
	case 4: printf("Orta   ");break;
		   }
    } while(!kbhit()); // klavye tu�u bas�lana kadar beklenir

 saklafare(); // fare saklan�r
 inregs.x.ax = 0x13;
 int86x(0x10, &inregs, &outregs, &segregs);  // grafik ekrana ge�ilir

 getch();
 sinirlafare(20,20,100,100); // fare s�n�rlan�r
 koyfare(60,60); // s�n�r�n ortas�na konur
 gosterfare(); // fare g�sterilir (grafik modunda)
	       // yukardaki i�lemler a�a��da da tekrarlan�r
 do {
    okufare(&iks,&ye,&dugme);
    gotoxy(1,1);printf("x:%3d",iks);gotoxy(7,1);printf("y:%3d",ye);
    gotoxy(13,1);
     switch(dugme) {
	case 0: printf("Bos    ");break;
	case 1: printf("Sol    ");break;
	case 2: printf("Sag    ");break;
	case 3: printf("Sol+Sag");break;
	case 4: printf("Orta   ");break;
		   }
    } while(!kbhit());

 saklafare();

 inregs.x.ax = 3;
 int86x(0x10, &inregs, &outregs, &segregs);

}

