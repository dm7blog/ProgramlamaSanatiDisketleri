#include <ctype.h>
#include <conio.h>
#include <dos.h>
#include <stdio.h>

int menu_select();
void pspace(int count), go_xy(int x, int y), main_menu(), put_char(char a);
extern unsigned TallCursor, NoCursor;
void charbox()
{
    int test;

    /* draw top of box */
    char nw[]          = "�";
    char par[]       = "���������������������������������������";
    char ne[]        = "�";
    char vert[]      = "�";
    char sw[]        = "�";

    int loop;
    int x = 1;

    go_xy(0, 0);

    cputs(nw);
    cputs(par);
    cputs(par);
    cputs(ne);

    /* draw parallel lines down the sides */
    for (x = 1; x < 24; x++)
    {
        go_xy(x, 0);
        cputs(vert);
        go_xy(x, 79);
        cputs(vert);
    }

    /* draw bottom of box */
    cputs(sw);
    cputs(par);
    cputs(par);
    put_char('�');
}

void display_screen()
{
    go_xy(6, 18);
    cputs("enter first name:  ");
    go_xy(8, 18);
    cputs(" enter last name:  ");
    go_xy(10, 18);
    cputs("    enter street:  ");
    go_xy(12, 18);
    cputs("      enter city:  ");
    go_xy(14, 18);
    cputs("     enter state:  ");
    go_xy(16, 18);
    cputs("       enter zip:  ");
    go_xy(18, 18);
    cputs("     enter phone:  ");
}

void inputs(char *s, int count)
{
  char p[50];
  p[0] = count;
  p[1] = 0;

  textbackground(LIGHTGRAY);
  pspace(count);
  cgets(p);
  strcpy(s, p+2);
  textbackground(BLACK);
  if (*s == '\0')
  {
    textbackground(BLACK);
    window(1, 1, 80, 25);
    clrscr();
    charbox();
    window(2, 2, 79, 24);
    main_menu();
  }
}

void Beep(void)
{
  sound(750);
  delay(25);
  nosound();
}

void pspace(int count)
{
    int looper;
    for (looper = 0; looper < count; looper++)
        cputs(" ");
    for (looper = 0; looper < count; looper++)
        printf("\b");
}

void cls()
{
    union REGS r;
    r.h.ah = 6;
    r.h.al = 0;
    r.h.ch = 1;
    r.h.cl = 1;
    r.h.dh = 23;
    r.h.dl = 78;
    r.h.bh = 7;
    int86(0x10, &r, &r);
}

void go_xy(int x, int y)
{
    union REGS r;
    r.h.ah = 2;
    r.h.dl = y;
    r.h.dh = x;
    r.h.bh = 0;
    int86(0x10, &r, &r);
}

void put_char(char a)
{
    union REGS r;
    r.h.ah = 9;
    r.h.al = a;
    r.h.bl = 14;
    r.h.bh = 0;
    r.x.cx = 1;
    int86(0x10, &r, &r);
}

int getkey(void)
/* Uses the BIOS to read the next keyboard character */
{
 int key, lo, hi;

 key = bioskey(0);
 lo = key & 0X00FF;
 hi = (key & 0XFF00) >> 8;
 return((lo == 0) ? hi + 256 : lo);
} /* getkey */

void field(char *field, int max)
{
    int loop;

    for (loop = 0; loop < max; loop++)
    {
	cputs(" ");
    }

    for (loop = 0; loop < max; loop++)
    {
        cprintf("\b");
    }

    cprintf("%s", field);

    for (loop = 0; loop < strlen(field); loop++)
    {
        cprintf("\b");
    }
} /* field */

int menu_select()
{
    int x, y, c, selection;
    char sel[4];
    
    strcpy(sel, "");

    main_menu();

    SetCursor(TallCursor);

    do
    {
	edit_field(51, 22, sel, 2, LIGHTGRAY, YELLOW);
	selection = atoi(sel);
        go_xy(22, 51);
    } while ((selection < 1) || (selection > 10));

    SetCursor(NoCursor);
    return (selection);
}

void main_menu()
{
    cls();

    go_xy(2, 25);
    textcolor(WHITE); cputs("1"); textcolor(YELLOW); cputs(".  Add A Record");
    go_xy(4, 25);
    textcolor(WHITE); cputs("2"); textcolor(YELLOW); cputs(".  Remove A Record");
    go_xy(6, 25);
    textcolor(WHITE); cputs("3"); textcolor(YELLOW); cputs(".  Write Labels To Disk");
    go_xy(8, 25);
    textcolor(WHITE); cputs("4"); textcolor(YELLOW); cputs(".  Display A Record");
    go_xy(10, 25);
    textcolor(WHITE); cputs("5"); textcolor(YELLOW); cputs(".  Edit A Record");
    go_xy(12, 25);
    textcolor(WHITE); cputs("6"); textcolor(YELLOW); cputs(".  Save The File");
    go_xy(14, 25);
    textcolor(WHITE); cputs("7"); textcolor(YELLOW); cputs(".  Retrieve The File");
    go_xy(16, 25);
    textcolor(WHITE); cputs("8"); textcolor(YELLOW); cputs(".  Browse Through List");
    go_xy(18, 25);
    textcolor(WHITE); cputs("9"); textcolor(YELLOW); cputs(".  DOS Shell");
    go_xy(20, 25);
    textcolor(WHITE); cputs("10"); textcolor(YELLOW); cputs(".  Exit Program");
    go_xy(22, 25);
    
    cputs("Select Number of Choice:  ");
}

