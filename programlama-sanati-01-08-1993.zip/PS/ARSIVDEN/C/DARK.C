

/*                                     */
/*  =+= M.MURAT DiCLE 1992 =+=         */
/*    =+= EKRAN KARARTMA =+=           */
/*                                     */
/* Program TC++'da yazilmistir.        */
/* TURBO C ya da TURBO C++ komut       */
/* satirinda derlemek icin;            */
/*    TCC -N-O-Z-r-ms DARK             */
/* yazarak programi derleyebilirsiniz. */
/*                                     */

#include <dos.h>
#include <stdio.h>

/* 1 saniye  = 18 birim.              */
/* bilgisayar 8. interruptta saniyede */
/* 18.2 defa gelir.                   */
#define birim 18

/* SURE saniye cinsinden olmalidir. */
#define SURE 60

/* tusa basilmayan her 1 dakika sonunda ekran kararir. */
#define ZAMAN SURE*birim

extern unsigned _heaplen = 1024;
extern unsigned _stklen  = 512;
unsigned sayac = 0;
char durum = 0;
char scr = 0;
char far *ekran;
void interrupt DARK(void);
void interrupt (*int8)(void);

void interrupt DARK(void)
{
    int8();
    if (durum) return;
    if (!(inportb(0x60) & 128) && !scr)
       sayac = 0;
    else if (!(inportb(0x60) & 128) && scr)
            {
            int i = 0;
            durum = 1;
            scr = 0;
            sayac = 0;
            while (i++ < 4000) ekran[i] = ekran[4000 + i];
            durum = 0;
            }
    if (!scr) sayac++;
    if (sayac > ZAMAN)
       {
       int i = 0;
       durum = 1;
       while (i++ < 4000)
             {
             ekran[4000 + i]  = ekran[i];
             ekran[i] = 0;
             }
       scr = 1;
       sayac = 0;
       durum = 0;
       }
}

void main()
{
   printf("\n      =+= EKRAN KARARTMA =+=");
   printf("\n=+= (c) 1992 by M. Murat DiCLE =+=");
   printf("\n\ntusa basmadiginiz her %d saniye sonunda\n", SURE);
   printf("ekraniniz bir tusa basilincaya kadar karartilir.\n\n");

   /* saat interrupt'tina DARK fonksiyonu yerlesti */
   int8 = getvect(8);
   setvect(8, DARK);

   /* ekran tipi belirleniyor..! */
   /* 0xB000 monu ekran          */
   /* 0xB800 rekli ekran         */
   if (peekb(0x0040, 0x0049) == 7)
          ekran = MK_FP(0xB000, 0);
       else
          ekran = MK_FP(0xB800, 0);
   keep(0, (_SS + (_SP / 16) - _psp));
}