



#include <stdio.h>
#include <dos.h>
#include "key.h"


void main()
{
 int c, row, col;
 char sbuf[64];

 mouse_reset();

 _getvideo();           /* Bana ait */
 clrscr();

 writes(24, 0, " �IKI� ", REV);     /* Bana ait */
 mouse_on();

 for (;;) {
  c = get_mouse(&row, &col);
  if ((row == 24) && ((col >= 0) && (col <= 9)) && (c == 1))
   break;
  sprintf(sbuf, "Row = %2d   Col = %2d   Key: %d",
   row, col, c);
  writes(24, 40, sbuf, CYAN);
  }
 mouse_off();
}