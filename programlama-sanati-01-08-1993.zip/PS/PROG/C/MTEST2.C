


#include <stdio.h>
#include "key.h"

main()
{
 int mouse_map[32] = {1,1,1,1,0,0,0,0,0,0,0,0,2,2,2,2,0,0,0,0,0,0,0,0,
        3,3,3,3,3,3,3,3};
/* Fare dizisine ilk de�er veriliyor */

  char sbuf[5];
  unsigned col;

_getvideo();

mouse_reset();
mouse_on();

clrscr();

_writes(0,0,  "FILE");
_writes(0,12, "SAVE");
_writes(0,24, "RETRIEVE");
_writes(24,0,"Klavye tu�unun kodu ya da fare konumu ="); _writes(24,49,"Son
se�ilen eleman=");


 while (!(right_button() && left_button())) {
  col = getkb();

  if (col > 32) {
        sprintf(sbuf,"%04x",col);
        _writes(20,40,sbuf);
         continue;
        }

  switch (mouse_map[col])
  {
   case 1 : _writes(24,70, "FILE      "); break;
   case 2 : _writes(24,70, "SAVE      "); break;
   case 3 : _writes(24,70, "RETRIEVE  "); break;
   case 0 : sprintf(sbuf,"%04x", col);
            _writes(24,40,sbuf); break;
   }

 }   /* while */

}