#include <stdio.h>
#include <conio.h>
#include <dos.h>
#include <stdlib.h>
#include <string.h>

union   REGS    regs;
struct  SREGS   segregs;
struct vesa{
  char          vesa[4];        // VESA yazisi
  unsigned char secver;         // Ikincil versiyon
  unsigned char mainver;        // Ana versiyon
  char far      *manifacturer;  // Uretici firma
  unsigned long flag;           // Kullanilmiyor
  unsigned far  *modes;         // Kartin destekledigi modlar
  }infobuf,*iptr=&infobuf;

struct vesamod{
  unsigned      modeflag;        // VESA modu bilgileri
  unsigned      char firstflag;  // ilk pencere bilgileri
  unsigned      char secflag;    // ikinci pencere bilgileri
  unsigned      granularity;     // VESA penceresi hareket orani
  unsigned      size;            // VESA penceresi boyu
  unsigned      firstseg;        // ilk pencerenin segment adresi
  unsigned      secseg;          // ikinci pencerenin segment adresi
  void far      *routine;        // video RAM'daki pencere yerini belirten
                                 // rutinin adresi
  unsigned      pixelperline;    // bir satirdaki pixel sayisinin toplam
                                 // tuttugu byte sayisi
  unsigned      x;               // X cozunurlugu
  unsigned      y;               // Y cozunurlugu
  unsigned char width;           // text modlari icin karakterlerin
                                 // X cozunurlugu
  unsigned char height;          // text modlari icin karakterlerin
                                 // Y cozunurlugu
  unsigned char bitplanes;       // bitplane sayisi
  unsigned char bits;            // pixel basina dusen bit sayisi
  unsigned char memblock;        // hafiza blogu sayisi
  unsigned char memmodel;        // hafiza tipi
  unsigned char memsize;         // hafiza blogu boyutu(KB)
  }modbuf,*mptr=&modbuf;


void main(void)
{
int a,dum;
char dummy[150];

      regs.h.ah = 0x4F;               /* VESA fonksiyonu */
      regs.h.al = 0x00;               /* 0 no'lu altfonksiyon:*/
                                      /* SVGA kartinin ozellikleri? */
      segregs.es = FP_SEG(iptr);
      regs.x.di = FP_OFF(iptr);
      int86x(0x10, &regs, &regs, &segregs);

      if (regs.h.ah!=0){
           printf("\n Bu grafik karti VESA fonksiyonlarini desteklemez.\n");
           exit(1);
           }
      strncpy(dummy,infobuf.vesa,4);
      dummy[4]='\0';
      printf("\n%s: v%d.%d",dummy,infobuf.mainver,infobuf.secver);
      _fstrcpy(dummy,infobuf.manifacturer);
      printf("\nFirma: %s \nDesteklenen modlar:",dummy);
      while (*infobuf.modes!=0xFFFF){
           printf("\n                     Mod: %Xh",*infobuf.modes);
           regs.h.ah = 0x4F;  /* VESA fonksiyonu */
           regs.h.al = 0x01;  /* 1 no'lu altfonksiyon:*/
                              /* VESA modunun ozellikleri?*/
           regs.x.cx = *infobuf.modes;
           segregs.es = FP_SEG(mptr);
           regs.x.di = FP_OFF(mptr);
           int86x(0x10, &regs, &regs, &segregs);
           for(a=0,dum=1;a<modbuf.bits;a++,dum*=2);// bit sayisindan
                                                   // renk sayisi hesaplaniyor
           if ((modbuf.modeflag&16)==16) // Mode flag 4. bit modun
                                         //Grafik/Text oldugunu belirtir
		strcpy(dummy,"Grafik modu"); else strcpy(dummy,"Text modu");
                printf(" (%dx%d) %d renk %s.",modbuf.x,modbuf.y,dum,dummy);
                infobuf.modes++;
                }
          printf("\n");
          exit(0);
}