#include <process.h>
#include <stdio.h>
#include <bios.h>
#include <conio.h>
#include <stdlib.h>
#include <dos.h>
#define RECEPTEZKOL 0
#define HASANTEZKOL 1
#define GRF    0x13
#define TXT    3
#define byte unsigned char


extern int  far ply();   /* player - ply.obj*/
extern char far mzk[];   /* m�zik  -        */
extern char far rec[];   /* resim 1 */
extern char far has[];   /* resim 2 */

char temp[768];
int Kart=0;

void Screen(byte mode)
{
asm	mov al,mode
asm	mov ah,0
asm	int 10h
}

void SetPalet(char pal[])
{
	_ES=FP_SEG(pal);
	_DX=FP_OFF(pal);
asm{    mov	bx,0
	mov	cx,256
	mov	ax,1012h
	int	10h
	}
}

void Fadein()
{
int x,i;
	for(x=20;x>0;x--){
		for(i=1;i<=0x300;i++) temp[i]=rec[32+i]*x/20;
		SetPalet(temp);
		delay(50);
		}
}

void Fadeout()
{
int x,i;
	for(x=0;x<21;x++){
		for(i=1;i<=0x300;i++) temp[i]=rec[32+i]*x/20;
		SetPalet(temp);
		delay(50);
		}
}

void put(int x,int y,int c)
{
	pokeb(0xa000,(y)*320+(x),c);
}


void goster(char r[])
{
int x,i,say,q,w;
	q=(byte)r[2];w=(byte)r[4];
	Fadein();
	say=0x320;
	for(x=0;x<w;x++){
		for(i=0;i<q;i++){
			put(i+100,x,r[say++]);
			}
		}
	Fadeout();
}

void SoundOn()
{
	_AH=4;
	if(ply()!=-1){
		_ES=FP_SEG(mzk);
		_SI=FP_OFF(mzk);
		_AH=0;
		_BX=0;
		ply();
		Kart=1;
		}
}

void SoundOff()
{
	if(Kart){
		_AH=2;
		ply();
		}
}

void screeninit()
{
register int x;
asm mov	ax,1a00h
asm int	10h
	if(_AL!=0x1a){
		printf("VGA kart� bulunamad�..\n");
		exit(1);
		}
	for(x=42;x>=0;x--){
		_CL=x;
		_CH=x;
		_DH=x;
		_AX=0x1010;
		_BX=7;
		asm int 10h;
		}
	Screen(GRF);
	for(x=0;x<768;x++) temp[x]=0;
}

void screendone()
{
	Screen(TXT);
	gotoxy(1,25);
	printf("\t\tPrizma- Turkish amateur programmers' group.\n");
	printf("\t\t--------------Recep Tezkol.----------------\n");
}




void main()
{
int  kim=HASANTEZKOL;
	screeninit();
	SoundOn();
	goster(rec);
	do{
		switch(kim){
			case RECEPTEZKOL:goster(rec);
					 kim=HASANTEZKOL;
					 break;
			case HASANTEZKOL:goster(has);
					 kim=RECEPTEZKOL;
					 break;
			}
		}while(!bioskey(1));
	SoundOff();
	screendone();
}
