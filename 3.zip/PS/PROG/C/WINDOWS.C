/*--------------------------------*\
|* OOP demo.                      *|
|* Nesneler: POINT, BOX, WINDOWS  *|
|* 1993 By M. Murat DiCLE         *|
|* TC++ 1.0 yada sonras�          *|
\*--------------------------------*/
#include <alloc.h>   // alloc
#include <conio.h>   // gettext, puttext, putch, textcolor
#include <string.h>  // strcpy
#include <dos.h>     // delay
#include <stdlib.h>  // randomize, random
#include <stdio.h>   // gets

#define SOL_UST_KOSE 201
#define SAG_UST_KOSE 187
#define SOL_ALT_KOSE 200
#define SAG_ALT_KOSE 188
#define YATAY_CIZGI  205
#define DIK_CIZGI    186

void yazch(char xx, char yy, char cc)
{
   if (xx < 81 && xx > 0 && yy < 25 && yy > 0)
      {
      gotoxy(xx, yy);
      putch(cc);
      }
}

void color(char xx, char yy)
{
   textcolor(xx);
   textbackground(yy);
}


/*--------------------------------*\
|* POINT s�n�f� tan�mlan�yor..    *|
\*--------------------------------*/
class POINT
      {
      protected:
      char x, y;
      char gorunur;  // 0 hay�r, 1 Evet
      public:
      POINT (char xx, char yy)
	    {
	    x = xx;
	    y = yy;
	    gorunur = 1;
	    }
      void show(void) { gorunur = 1;}
      void hide(void) { gorunur = 0;}
      void move(char xx, char yy)
	   {
	   x = xx;
	   y = yy;
	   }
      char getx(void) { return x;}
      char gety(void) { return y;}
      };


/*-------------------------------------------------------------*\
|* BOX s�n�f� POINT s�n�f�ndan miras alarak tan�mlan�yor..     *|
\*-------------------------------------------------------------*/
class BOX: public POINT
      {
      protected:
      char genislik, yukseklik;
      public:
      BOX (char xx, char yy, char ww, char hh):
	  POINT(xx, yy)
	  {
	  genislik  = ww;
	  yukseklik = hh;
	  }
      void box_move(char xx, char yy);
      void box_resize(char ww, char hh);
      void box_redraw(void);
      void setwh(char ww, char hh);
      };

void BOX::setwh(char ww, char hh)
{
   genislik  = ww;
   yukseklik = hh;
}

void BOX::box_move(char xx, char yy)
{
   move(xx, yy);
   box_redraw();
}

void BOX::box_resize(char ww, char hh)
{
   setwh(ww, hh);
   box_redraw();
}

void BOX::box_redraw(void)
{
   char i, ii;
   yazch(x, y, SOL_UST_KOSE);
   yazch(x + genislik - 1, y, SAG_UST_KOSE);
   yazch(x, y + yukseklik - 1, SOL_ALT_KOSE);
   yazch(x + genislik - 1, y + yukseklik - 1, SAG_ALT_KOSE);
   for (i = x + 1; i < x + genislik - 1; i++)
       {
       yazch(i, y, YATAY_CIZGI);
       yazch(i, y + yukseklik - 1, YATAY_CIZGI);
       }
   for (i = y + 1; i < y + yukseklik - 1; i++)
       {
       yazch(x, i, DIK_CIZGI);
       yazch(x + genislik - 1, i, DIK_CIZGI);
       for (ii = x + 1; ii < x + genislik - 1; ii++) yazch(ii, i, 32);
       }
}

/*-------------------------------------------------------------*\
|* WINDOWS s�n�f� BOX s�n�f�ndan miras alarak tan�mlan�yor..   *|
\*-------------------------------------------------------------*/
class WINDOWS:public BOX
      {
      protected:
      char *scrbuf;
      char col1, col2;
      public:
      WINDOWS(char xx, char yy, char ww, char hh, char co1, char co2);
      ~WINDOWS (void) { free(scrbuf); }
      virtual void win_resize(char ww, char hh);
      virtual void win_move(char xx, char yy);
      virtual void win_show(void);
      virtual void win_hide(void);
      virtual void win_redraw(void);
      virtual void win_printf(char xx, char yy, char *s);
      };


WINDOWS::WINDOWS(char xx, char yy, char ww,
		 char hh, char co1, char co2):
		 BOX(xx, yy, ww, hh)
{
   // Altta kalan g�r�nt�y� saklamak i�in kullan�lacakt�r.
   scrbuf   = (char *) malloc((ww * hh * 2) + 100);
   col1 = co1;
   col2 = co2;
   gettext(x, y, x + genislik - 1, y + yukseklik - 1, scrbuf);
   win_redraw();
}

void WINDOWS::win_redraw()
{
   color(col1, col2);
   box_redraw();
   gorunur = 1;
}

void WINDOWS::win_resize(char ww, char hh)
{
   char g;
   g = gorunur;
   win_hide();
   setwh(ww, hh);
   free(scrbuf);
   scrbuf = (char *) malloc((genislik * yukseklik * 2) + 100);
   gettext(x, y, x + genislik - 1, y + yukseklik - 1, scrbuf);
   gorunur = g;
   if (gorunur) win_redraw();
}

void WINDOWS::win_move(char xx, char yy)
{
   char g;
   g = gorunur;
   win_hide();
   gettext(xx, yy,xx + genislik - 1, yy + yukseklik - 1, scrbuf);
   box_move(xx, yy);
   if (g) win_redraw();
}

void WINDOWS::win_show(void)
{
   win_redraw();
}

void WINDOWS::win_hide(void)
{
   puttext(x, y, x + genislik - 1, y + yukseklik - 1, scrbuf);
   gorunur = 0;
}

void WINDOWS::win_printf(char xx, char yy, char *s)
{
   if (xx > 0 && xx < genislik)
      if (yy > 0 && yy < yukseklik)
	 while ((*s != 0) && (x + xx) < (x + genislik - 1))
	       yazch(x + (xx++), y + 1, *s++);
}

/*----------------------------\
|* DEMO program ba�lang�c�   *|
\*---------------------------*/
void main(void)
{
   char i;
   WINDOWS pencere(1, 1, 30, 15, 15, 1);
   randomize();
   for (i = 0; i < 5; i++)
       {
       delay(300);
       pencere.win_resize(random(60) + 10, random(15) + 5);
       pencere.win_printf(1, 1, "ABCDEFGHIJKLMNOPRSTUVYZ");
       }
   for (i = 0; i < 3; i++)
       {
       delay(400);
       pencere.win_hide();
       delay(200);
       pencere.win_show();
       pencere.win_printf(1, 1, "ABCDEFGHIJKLMNOPRSTUVYZ");
       }
   pencere.win_resize(20, 10);
   randomize();
   for (i = 0; i < 5; i++)
       {
       pencere.win_move(random(50) + 1, random(20) + 1);
       pencere.win_printf(1, 1, "1 2 3 4 5 6 7 8 9 0 1 2 3 4");
       delay(500);
       }
   pencere.win_hide();
   color(15, 4);
   BOX kutu(20, 10, 70, 20);
   kutu.box_redraw();
   getch();
   kutu.box_move(1, 1);
}