/*  A�a��daki program TSR programlar�n�n a��klanmas�nda kullan�lmak �zere
*   e�itim ama�l� tasarlanm��t�r.
*/

#include <stdio.h>
#include <dos.h>
#include <stdlib.h>

#define F1    0x3b00
#define F2    0x3c00

int videobuf;

typedef struct _CHR {
	char chr;
	char atr;
	} CHR;

void interrupt (*timer_int)();
void interrupt (*keyb)();
void interrupt deactivate(void);

void _getvideo(void)
{
	union REGS  vregs;

	vregs.h.ah = 0xf;

	int86(0x10,&vregs, &vregs);

	if (vregs.h.al == 2 || vregs.h.al == 3) {
		videobuf = 0xb800;
		return;
		}

	if (vregs.h.al == 7) {
		videobuf = 0xb000;
		return;
		}   else {
		printf("\nChange your video mode...");
		exit(1);
		}
}

void _writes(int row, int col, char *str)
{
	CHR far *chp;

	chp = (CHR far *) ((long) videobuf << 16 | 0L);
	chp += row * 80 + col;

	while (*str != NULL) {
		chp -> chr = *str;
		++chp;
		++str;
		}
}

int get_last_buffer(void)
{
	int far *t2 = (int far *) 1050;
	char far *t = (char far *) 1050;

	if (*t != *(t+2)) {
		t += *t - 30 + 4;
		*(t2+1) = *t2;
		return *(int far *) t;
		}
}


void interrupt virus(void)
{
	int ran;
	static int row = 12, col = 40;

	ran = rand() % 4;

	row %= 24;
	col %= 79;

	if (row < -1)
		row = 24;
	if (col < -1)
		col = 79;

	switch (ran)
	{
		case 0 :_writes(row, col, " "); row++;
			_writes (row, col,"*"); break;
		case 1 : _writes (row, col," "); row--;
			_writes (--row, col,"*"); break;
		case 2 :_writes (row, col," "); col++;
			_writes (row, col,"*"); break;
		case 3 :_writes (row,col," "); col--;
			_writes (row,--col,"*"); break;
	}

	(*timer_int)();
}

void interrupt activate(void)
{

	(*keyb)();

	if (get_last_buffer() == F1) {
	setvect(0x08,virus);
	setvect(0x9,deactivate);
	}
	(*keyb)();
}

void interrupt deactivate(void)
{

	(*keyb)();
	if (get_last_buffer() == F2) {
	setvect(0x8, timer_int);
	setvect(0x89,keyb);
	}
	(*keyb)();
}

main()
{
	_getvideo();
	randomize();
	timer_int = getvect(0x08);
	keyb = getvect(0x9);
	setvect(0x9,activate);
	keep(1,0x1000);
}

