//REGEN_FILEHEADING
//REGEN_FILEHEADING


     /********************************************************************
      *                                                                  *
      *   Source File: FX_RESOU.c                                        *
      *   Date:        Wed Oct 21 20:37:02 1992                          *
      *                                                                  *
      ********************************************************************/

#include <windows.h>
#include "FX.h"
#include <string.h>


//REGEN_VARIABLES

char Text[12]="AbraCadabra";
short FLAGU,FLAGD,FLAGP,FLAGB,FLAGS;

//REGEN_VARIABLES

HWND     hDlgFX_RESOURCE;

BOOL FAR PASCAL  fnFX_RESOURCEDlgProc(HWND, WORD, WORD, LONG);

#pragma argsused
int fnFX_RESOURCE(HWND hParentWnd)
{
int   RetCode;

FARPROC  lpfnfnFX_RESOURCEDlgProc;
   //REGEN_BEGINFUNCTION
   //REGEN_BEGINFUNCTION

   lpfnfnFX_RESOURCEDlgProc = MakeProcInstance(fnFX_RESOURCEDlgProc, hInst);

   //REGEN_INITDLG
   //REGEN_INITDLG

   if((RetCode = DialogBox(hInst, "FX_RESOURCE", hParentWnd, lpfnfnFX_RESOURCEDlgProc)) == -1)
   {
        MessageBox(NULL, "Unable to display dialog", "System Error",
                   MB_SYSTEMMODAL | MB_ICONHAND | MB_OK);
        return FALSE;
   }

   //REGEN_TERMDLG
   //REGEN_TERMDLG

   FreeProcInstance((FARPROC)lpfnfnFX_RESOURCEDlgProc);
   return(RetCode);
}


#pragma argsused
BOOL FAR PASCAL fnFX_RESOURCEDlgProc(HWND hDlg, WORD wMessage, WORD wParam, LONG lParam)
{


   switch(wMessage)
   {
   //REGEN_WINDOWPROCVARIABLES

   //REGEN_WINDOWPROCVARIABLES

       //REGEN_WINDOWPROC
       //REGEN_WINDOWPROC

       case WM_INITDIALOG :
          //REGEN_WM_INITDIALOG
	    FLAGB=FLAGS=0;
	  //REGEN_WM_INITDIALOG
	  return TRUE;

       case WM_COMMAND : 
            switch(wParam)
            {
               case 101 :
		 //REGEN_101
		 //REGEN_101
		 return TRUE;

               case 102 :
		 //REGEN_102
		 CheckDlgButton(hDlg,102,1);
		 CheckDlgButton(hDlg,103,2);
		 CheckDlgButton(hDlg,104,2);
		 FLAGU=1,FLAGD=0,FLAGP=0;
		 MessageBox(hDlg,"Dollar Chosen","USD",MB_SYSTEMMODAL|MB_ICONHAND|MB_OK);
		 //REGEN_102
		 return TRUE;

               case 103 :
		 //REGEN_103
		 CheckDlgButton(hDlg,103,1);
		 CheckDlgButton(hDlg,102,2);
		 CheckDlgButton(hDlg,104,2);
		 FLAGD=1,FLAGU=0,FLAGP=0;
		 MessageBox(hDlg,"Mark Chosen","DM",MB_SYSTEMMODAL|MB_ICONHAND|MB_OK);
		 //REGEN_103
		 return TRUE;

	       case 104 :
		 //REGEN_104
		 CheckDlgButton(hDlg,104,1);
		 CheckDlgButton(hDlg,102,2);
		 CheckDlgButton(hDlg,103,2);
		 FLAGP=1,FLAGU=0,FLAGD=0;
		 MessageBox(hDlg,"Pound Chosen","Pound",MB_SYSTEMMODAL|MB_ICONHAND|MB_OK);
		 //REGEN_104
		 return TRUE;


               case 109 :
                 //REGEN_109
		 MessageBox(hDlg,"Buy Option Chosen","Buy",MB_SYSTEMMODAL|MB_ICONHAND|MB_OK);
		 CheckRadioButton(hDlg,109,110,109);
		 FLAGB=1,FLAGS=0;
		 //REGEN_109
		 return TRUE;

	       case 110 :
		 //REGEN_110
		 MessageBox(hDlg,"Sell Option Chosen","Sell",MB_SYSTEMMODAL|MB_ICONHAND|MB_OK);
		 CheckRadioButton(hDlg,109,110,110);
		 FLAGB=0,FLAGS=1;
		 //REGEN_110
		 return TRUE;

	       case 111 :
		 //REGEN_111
		 GetDlgItemText(hDlg,105,Text,12);
		 if((FLAGB==1)||(FLAGS==1))
		 EndDialog(hDlg,TRUE);
		 else  {
		 MessageBox(hDlg,"Please click either Buy or Sell button","Error",MB_ICONEXCLAMATION | MB_OK );
		 EndDialog(hDlg,FALSE); }

		 //REGEN_111
		 return TRUE;

	       case 112 :
		 //REGEN_112
		  EndDialog(hDlg,FALSE);
		 //REGEN_112
		 return TRUE;

	       default :
		 return FALSE;
	    }

       case WM_SYSCOMMAND :
             //REGEN_SYSCOMMAND
             //REGEN_SYSCOMMAND
            switch(wParam & 0xFFF0)
            {
		case SC_CLOSE :
		     EndDialog(hDlgFX_RESOURCE, FALSE);
		     return TRUE;
            }

   }
   return FALSE;
}

//REGEN_CUSTOMCODE
//REGEN_CUSTOMCODE

