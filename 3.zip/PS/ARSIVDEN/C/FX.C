//REGEN_FILEHEADING
//REGEN_FILEHEADING


     /********************************************************************
      *   by CEM PAYASLIOGLU                                                               *
      *   Source File: FX.c                                              *
      *   Date:        Wed Oct 21 20:36:56 1992                          *
      *                                                                  *
      ********************************************************************/
#include <stdio.h>
#include <windows.h>
#include "FX.h"
#include <string.h>
#define MAX 100
#define SCROLLWIDTH 100
#define SCROLLLINES 100
extern int FLAGU,FLAGD,FLAGP,FLAGB,FLAGS;
extern char Text[12];

//REGEN_VARIABLES
//REGEN_VARIABLES

long FAR PASCAL MainWndProc(HWND, unsigned, WORD, LONG);
HANDLE   hInst;

#pragma argsused
int PASCAL WinMain(HANDLE hInstance,       // Module instance handle
                   HANDLE hPrevInstance,   // Handle to previous module instance
                   LPSTR  lpszCmdLine,     // Pointer to command line arguments
                       int    nCmdShow)    // Show window flag
{
static char szAppName[] = "FX";
MSG      msg;
HWND     hWndMain;
WNDCLASS wndclass;

//REGEN_BEGINFUNCTION
//REGEN_BEGINFUNCTION

HANDLE hBorLibrary;

   hBorLibrary = LoadLibrary("bwcc.dll");

   hInst = hInstance;    // Store the application instance handle 
   if(!hPrevInstance)
   {
      wndclass.style           = CS_HREDRAW | CS_VREDRAW;
      wndclass.lpfnWndProc     = MainWndProc;
      wndclass.cbClsExtra      = 0;
      wndclass.cbWndExtra      = 0;
      wndclass.hInstance       = hInstance;
      wndclass.hCursor         = LoadCursor(NULL, IDC_ARROW);
      wndclass.hIcon           = LoadIcon(hInstance,"FX");
      wndclass.hbrBackground   = CreateSolidBrush(GetSysColor(COLOR_WINDOW));
      wndclass.lpszMenuName    = "FX";
      wndclass.lpszClassName   = szAppName;

      if(!RegisterClass(&wndclass))
         return FALSE;
   }
   //REGEN_INITVIEW
   //REGEN_INITVIEW

   if(!(hWndMain = CreateWindow(szAppName,
                       "Application Caption",
		       WS_OVERLAPPEDWINDOW|WS_VSCROLL|WS_HSCROLL,
                       CW_USEDEFAULT, 0,
                       CW_USEDEFAULT, 0,
                       NULL, NULL, hInstance, NULL)))
        return FALSE;

   //REGEN_MAINWND
   //REGEN_MAINWND

   ShowWindow(hWndMain, nCmdShow);
   UpdateWindow(hWndMain);

   //REGEN_MAINEND
   //REGEN_MAINEND

   while(GetMessage(&msg, NULL, 0, 0))
          {
             TranslateMessage(&msg);
             DispatchMessage(&msg);
          }

   if(hBorLibrary > 32);
      FreeLibrary(hBorLibrary);
   //REGEN_APPTERM
   //REGEN_APPTERM



   return msg.wParam;
}

long FAR PASCAL MainWndProc(HWND hWnd, unsigned wMessage, WORD wParam, LONG lParam)
{
//REGEN_WINDOWPROCVARIABLES
int t;
HDC DC;
TEXTMETRIC tm;
static short charwt,charht,xClientView,yClientView,poshorzscroll,posvertscroll;
//REGEN_WINDOWPROCVARIABLES

   switch(wMessage)
   {
       //REGEN_WINDOWPROC
       //REGEN_WINDOWPROC
       case WM_CREATE:                   /* Gezinme (Scroll) kismi Murray & Pappas'tan  */
	  DC=GetDC(hWnd);                /*   alinmistir                     */
	  GetTextMetrics(DC,&tm);
	  charwt=tm.tmAveCharWidth;
	  charht=tm.tmHeight+ tm.tmExternalLeading;
	  ReleaseDC(hWnd,DC);
	  SetScrollPos(hWnd,SB_HORZ,poshorzscroll,TRUE);
	  SetScrollPos(hWnd,SB_VERT,posvertscroll,TRUE);
	  SetScrollRange(hWnd,SB_HORZ, 0, SCROLLWIDTH,FALSE);
	  SetScrollRange(hWnd,SB_VERT, 0, SCROLLLINES,FALSE);
	  break;
       case WM_SIZE:
	  xClientView=LOWORD(lParam);
	  yClientView=HIWORD(lParam);
	  break;
       case WM_HSCROLL:
	  switch(wParam)
	   {
	   case SB_LINEDOWN:
	   poshorzscroll+=1;
	   break;
	   case SB_LINEUP:
	   poshorzscroll-=1;
	   break;
	   case SB_PAGEDOWN:
	   poshorzscroll+=xClientView/charwt;
	   break;
	   case SB_PAGEUP:
	   poshorzscroll-=xClientView/charwt;
	   break;
	   case SB_THUMBPOSITION:
	   poshorzscroll=LOWORD(lParam);
	   break;
	   default:
	   break;
	   }
	   if(poshorzscroll>SCROLLWIDTH)
	      poshorzscroll=SCROLLWIDTH;
	   if(poshorzscroll<0)
	      poshorzscroll=0;
	   if(poshorzscroll!=GetScrollPos(hWnd,SB_HORZ))
	     {
	     SetScrollPos(hWnd,SB_HORZ,poshorzscroll,TRUE);
	     InvalidateRect(hWnd,NULL,TRUE);
	     }
	     break;
       case WM_VSCROLL:
	  switch(wParam)
	   {
	   case SB_LINEDOWN:
	   posvertscroll+=1;
	   break;
	   case SB_LINEUP:
	   posvertscroll-=1;
	   break;
	   case SB_PAGEDOWN:
	   posvertscroll+=yClientView/charwt;
	   break;
	   case SB_PAGEUP:
	   posvertscroll-=yClientView/charwt;
	   break;
	   case SB_THUMBPOSITION:
	   posvertscroll=LOWORD(lParam);
	   break;
	   default:
	   break;
	   }
	   if(posvertscroll>SCROLLLINES)
	      posvertscroll=SCROLLLINES;
	   if(posvertscroll<0)
	      posvertscroll=0;
	   if(posvertscroll!=GetScrollPos(hWnd,SB_VERT))
	     {
	     SetScrollPos(hWnd,SB_VERT,posvertscroll,TRUE);
	     InvalidateRect(hWnd,NULL,TRUE);
	     }
	     break;

       case WM_COMMAND :
	  if(!LOWORD(lParam))
	  {                             // Process Menu Commands
	     switch(wParam)             // Determine which Menu ID
	     {
             case IDM_START :
                if(fnFX_RESOURCE(hWnd))
                {
		//PROCESSMENU_START_BEGIN
		FILE *fp;
		HDC DC;
		short i,ch;
		char DosYa[13];
		static char szBuf[MAX]=" ";
		DC=GetDC(hWnd);
		if(!strcmp(Text,"View"))  {
		if(FLAGB && FLAGU)
		strcpy(DosYa,"DOLARAL.DOC");
		if(FLAGS && FLAGU)
		strcpy(DosYa,"DOLARSAT.DOC");
		if(FLAGB && FLAGD)
		strcpy(DosYa,"DMAL.DOC");
		if(FLAGS && FLAGD)
		strcpy(DosYa,"DMSAT.DOC");
		if(FLAGP&&(FLAGB||FLAGS)) {
		MessageBox(hWnd,"Pound Not Available Now","Sorry",MB_ICONEXCLAMATION | MB_OK );
		SendMessage(hWnd,WM_CLOSE,0,0L); }
		t=0;
		if((fp=fopen(DosYa,"r"))!=NULL)
		{
		 while(!feof(fp))
		 {
		 ch=fgetc(fp);
		 i=0;
		 while((ch!='\n')&&(ch!=EOF))
		  {
		  szBuf[i]=(char)ch;
		  ch=fgetc(fp);
		  i++;
		  }
		 TextOut(DC,-charwt*(poshorzscroll),
		 charht*(t-posvertscroll),szBuf,i);
		 t++;
		 }
		 }
		InvalidateRect(hWnd, NULL, NULL);
		ReleaseDC(hWnd,DC);
		fclose(fp);
		}
		else
		MessageBox(hWnd,"Please Enter View","Error",MB_ICONEXCLAMATION | MB_OK );
		InvalidateRect(hWnd, NULL, NULL);
		ReleaseDC(hWnd,DC);

		//PROCESSMENU_START_END

		}
		break;
	     case IDM_QUIT :
		{
                //PROCESSMENU_QUIT_BEGIN
		PostQuitMessage(0);
		//PROCESSMENU_QUIT_END

                }
                break;

             }
	  }
	  else
	  {
	     //REGEN_CUSTOMCOMMAND
	     //REGEN_CUSTOMCOMMAND

	  }
	   break;

       case WM_DESTROY :
	  //REGEN_WM_DESTROY
	  //REGEN_WM_DESTROY
	  PostQuitMessage(0);
	  break;

       default :
	    return DefWindowProc(hWnd, wMessage, wParam, lParam);
   }
   return 0L;
}

//REGEN_CUSTOMCODE
//REGEN_CUSTOMCODE

