/************************************************************************/
/*
** DISKSCAN.C - Scan all directories on a drive, and list them on the
**              screen.
**
**   usage:     DISKSCAN x:           (x is the drive letter)
**
**   To redirect the output to a text file:
**
**              DISKSCAN x: > filename.txt
**
**
**  Brain Child Systems    This program I release to the public domain,
**  P.O. Box 3882          ....but send me a dollar and make me holler!
**  Austin, TX 78764
**
*/

#include <stdio.h>
#include <string.h>
#include <dir.h>
#include <dos.h>

#define TRUE   1
#define FALSE  0

void
AppendMask(char *pacFullPath, char *pacPathSegment);

void
ClimbTree(char *pacFullPath, char *pacPathSegment,
          int *pfFoundDir);

void
RemoveDir(char *pacFullPath, int iHowMany);

void
RemoveMask(char *pacFullPath);

static char acDrive[] = "  \0";
static char acBackSlash[] = "\\*.\0";

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
*
*   AppendMask - Append the path segment onto the full
*     path name.
*
*/
void
AppendMask(char *pacFullPath, char *pacPathSegment) {

  if(!*pacPathSegment) {
    strcat(pacFullPath, acDrive);
    strcat(pacFullPath, acBackSlash);
    return;
  }
  strcat(pacFullPath, pacPathSegment);
  printf("%s\n", pacFullPath);
  strcat(pacFullPath, acBackSlash);

}
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
*
*   FUNCTION: ClimbTree
*
*
*/
void
ClimbTree(char *pacFullPath, char *pacPathSegment, int *pfFoundDir) {

  struct ffblk abFileBlock;
  int fDirFound = FALSE;

  RemoveMask(pacFullPath);
  AppendMask(pacFullPath, pacPathSegment);
  *pfFoundDir = FALSE;
  if(!findfirst(pacFullPath, &abFileBlock, FA_DIREC))
    do {
      if(strncmp(abFileBlock.ff_name, ".", 1) &&
		 abFileBlock.ff_attrib == FA_DIREC) {
        *pfFoundDir = TRUE;
        ClimbTree(pacFullPath, abFileBlock.ff_name,
                               &fDirFound);
      }
    } while(!findnext(&abFileBlock));

  if(!fDirFound)
    RemoveDir(pacFullPath, 2);

}
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
*
*   RemoveDir -
*
*/
void
RemoveDir(char *pacFullPath, int iHowMany) {

  while(*pacFullPath++);
  while(iHowMany--) {
    while(*pacFullPath != '\\')
        *pacFullPath-- = 0;

    if(iHowMany)
      *pacFullPath = 0;
  }

}
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */

/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - *
*
*   RemoveMask -
*
*/
void
RemoveMask(char *pacFullPath) {

  while(*pacFullPath++);
  while(*pacFullPath != '\\')
      *pacFullPath-- = 0;

}
/* - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - */


main(int argc, char *argv[]) {

  char cBackSlash[] = "\\";
  char acFullPath[100];
  char acPathSegment[13];
  int fDummy;

  if(argc < 2) {
    cprintf("which drive?");
    return;
  }
  else memcpy(acDrive, argv[1], 2);

  fDummy = TRUE;
  memset(&acFullPath, NULL, 100);
  memset(&acPathSegment, NULL, 13);
  ClimbTree(acFullPath, "", &fDummy);

}

