/************************************************************************
 *  Written by Tom Del Rosso for Microsoft Quick C from an algorithm    *
 *      in Scientific American's Computer Recreations of July 1987.     *
 *                                                                      *
 *  plots a bifurcation diagram of iterations of the algorithm:         *
 *                                                                      *
 *              for r = 0 to 4    ( r defines the y axis )              *
 *                  x = 0.3                                             *
 *                  for PLOT_ITERATION_COUNT iterations                 *
 *                      x = rx(1-x)                                     *
 *                      plot (x,r)                                      *
 *                                                                      *
 ************************************************************************/

#include <stdio.h>
#include <graph.h>


				/***************************
				 ***  DEFINE ADJUSTABLE  ***
				 ***     PARAMETERS      ***
				 ***************************/

											/* YOU CAN ZOOM TO ANY SCALE  *
											 * WITHIN DOUBLE PRECISION    *
											 * RESOLUTION.                *
											 * ALWAYS INCLUDE A DECIMAL   *
											 * POINT IN THE FIRST FIVE    *
											 * VALUES TO KEEP ANSI HAPPY. */

#define WIN_TOP                -2.0         /* -2.0 to +4.0 (normally 2.9)*/
#define WIN_BOTTOM              4.0         /* -2.0 to +4.0 (normally 4.0)*/

#define WIN_LEFT               -0.5         /* -0.5 to +1.5 (normally 0.0)*/
#define WIN_RIGHT               1.5         /* -0.5 to +1.5 (normally 1.0)*/


#define INIT_X                  0.3         /* initial x value (0 to 1,   *
											 * normally set to 0.3)       *
											 * before iterations begin    *
											 * for each r value           */

#define PLOT_ITERATION_COUNT    30          /* the number of plotted      *
											 * iterations (INTEGER)       */

#define INITIAL_BUF_COUNT       0           /* Non-plotted iterations     *
											 * hide initial x values in   *
											 * ranges with attractors, so *
											 * only atractors are shown.  *
											 * These iterations are       *
											 * done first, and are        *
											 * not plotted.  (INTEGER)    */

				/*******************************
				 ***  DEFINE MATHEMATICALLY  ***
				 ***     IMPOSED LIMITS      ***
				 *******************************/

#define ABS_MIN_Y              -2.0         /* any Y (or `r') value out  */
											/* of the range -2 to +4     */
#define ABS_MAX_Y               4.0         /* will cause x to oscillate */
											/* beyond -0.5 to +1.5, and  */
#define ABS_MIN_X              -0.5         /* then quickly approach     */
											/* negative and positive     */
#define ABS_MAX_X               1.5         /* infinity (ALL FLOATS)     */


				/***      DEFINE ERROR CODE RETURNED BY      ***
				 *** UNSUCCESSFUL ATTEMPTS TO SET VIDEO MODE ***/

#define VID_MODE_ERR            0

					/*****************
					 *** MAIN BODY ***
					 *****************/
main (void)
{
					/***   DECLARE TYPES   ***/

double x, r, step, k_x, k_y;
short  iter_cnt, gx, gy, color, delay;
struct videoconfig vdata;

					/***   TEST ZOOM WINDOW FOR LIMITS   ***/

if  (  WIN_TOP    < ABS_MIN_Y  ||  WIN_TOP    > ABS_MAX_Y
	|| WIN_BOTTOM < ABS_MIN_Y  ||  WIN_BOTTOM > ABS_MAX_Y
	|| WIN_TOP    >=  WIN_BOTTOM  )                         {
	printf ("The values for TOP and BOTTOM are out of the range of -2.0 to +4.0,\n");
	printf ("or they are in reversed order.\n\n");
	exit (1);
}

if  (  WIN_LEFT   < ABS_MIN_X  ||  WIN_LEFT   > ABS_MAX_X
	|| WIN_RIGHT  < ABS_MIN_X  ||  WIN_RIGHT  > ABS_MAX_X
	|| WIN_LEFT   >=  WIN_RIGHT   )                         {
	printf ("The values for LEFT and RIGHT are out of the range of -0.5 to +1.5,\n");
	printf ("or they are in reversed order.\n\n");
	exit (1);
}

					/***   TEST INITIAL X VALUE   ***/

if  (  INIT_X < 0.0 ||  INIT_X > 1.0 )     {
	printf ("The initial X value is out of the range of 0 to 1.\n\n");
	exit (1);
}

			/*** FIND BEST GRAPHICS (ASSUMING THAT RESOLUTION ***
			 *** IS MORE IMPORTANT THAN THE NUMBER OF COLORS; ***
			 *** YOU CAN REORDER THE MODES OTHERWISE)         ***/

if (_setvideomode(_VRES16COLOR /* 640x480 16 color */) == VID_MODE_ERR) {
	if (_setvideomode(_VRES2COLOR /* 640x480 B&W */) == VID_MODE_ERR) {
		if (_setvideomode(_ERESCOLOR /* 640x350 4/16 color */) == VID_MODE_ERR) {
			if (_setvideomode(_ERESNOCOLOR /* 640x350 B&W */) == VID_MODE_ERR) {
				if (_setvideomode(_HRES16COLOR /* 640x200 16 color */) == VID_MODE_ERR) {
					if (_setvideomode(_HRESBW /* 640x200 B&W */) == VID_MODE_ERR) {
						if (_setvideomode(_MRES256COLOR /* 320x200 256 color */) == VID_MODE_ERR) {
							if (_setvideomode(_MRES16COLOR /* 320x200 16 color */) == VID_MODE_ERR) {
								if (_setvideomode(_MRES4COLOR /* 320x200 4 color */) == VID_MODE_ERR) {
									if (_setvideomode(_MRESNOCOLOR /* 320x200 B&W */) == VID_MODE_ERR) {
										printf ("This program requires some type of graphics card.\n\n");
										exit (2);
									}
								}
							}
						}
					}
				}
			}
		}
	}
}

				/*** PASS VIDEO PARAMETERS TO vdata STRUCTURE ***/

_getvideoconfig(&vdata);

		/**********************************************************
		 **********************************************************
		 ***************     COMPUTE AND GRAPH      ***************
		 **********************************************************
		 **********************************************************/

				/***         INITIALIZE CONSTANTS         ***
				 ***   TO AVOID REPETITIVE CALCULATIONS   ***/

step = (WIN_BOTTOM - WIN_TOP) / vdata.numypixels;
k_x  = vdata.numxpixels / (WIN_RIGHT  - WIN_LEFT);
k_y  = vdata.numypixels / (WIN_BOTTOM  - WIN_TOP);

				/*** Do each y (`r') value ***/

for ( r = WIN_TOP ; r <= WIN_BOTTOM ; r += step ) {

	gy = (r - WIN_TOP) * k_y;                   /* gy is video coodinate */

	x = INIT_X;                                 /* x starts here        */

					/**********************************
					 ***  Run x through some number ***
					 ***  of iterations and don't   ***
					 ***  plot them, to hide the    ***
					 ***  initial values of x.      ***
					 **********************************/

	for ( iter_cnt = 0 ; iter_cnt < INITIAL_BUF_COUNT ; iter_cnt ++ )

		x = r * x * (1-x);

					/**********************************
					 ***    Run x through some      ***
					 ***    number of iterations    ***
					 ***    to create display.      ***
					 **********************************/

	for ( iter_cnt = 0 ; iter_cnt < PLOT_ITERATION_COUNT ; iter_cnt ++ ) {

		x = r * x * (1-x);

		gx = (x - WIN_LEFT) * k_x;

			/*** rotate colors from 1 to highest (skip color zero) ***/

		color = iter_cnt % (vdata.numcolors - 1) + 1;

			/*** plot ***/

		_setcolor (color);
		_setpixel (gx,gy);

					/*****************************************
					 *** an optional delay loop after each ***
					 *** pixel drawn makes the sequence of ***
					 *** iterative values more clear       ***
					 *****************************************/

		/* for ( delay = 0 ; delay < 2000 ; delay ++ ); */

	}
}

if (getch() == '\x00')                  /* wait for key, and if first   */
	getch();                            /* byte = 0, then it's not a    */
										/* character key so get         */
										/* extended (scan) code         */

_setvideomode (_DEFAULTMODE);           /* restore video mode           */
return (0);

}
