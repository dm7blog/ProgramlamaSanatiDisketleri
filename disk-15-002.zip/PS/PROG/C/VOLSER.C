/* This is a program that will read/write the volume serial
 * number of the default disk.
 * The program prompts for the new volume serial number.
 * If no change is required, just press ENTER to exit.
 * Use it just like the DOS command LABEL.
 * Usage: volser [?:]
 * 				where ?: is the drive holding the disk you want to change.
 * 				Default drive is A:
 * Problem: The atoi() function will not conver HEX characters
 * input from the keyboard. Thersfore you shoud convert your desired
 * serial number to DECIMAL before using it. If you try to use
 * HEX, and the number has a letter in it, you will not get what you expect.
 * Example: 12AB21B2 will return: 000C-0015
 * Example: 12345678 will return: 04D2-162E
 * Any letters stop the conversion to a number.
 * Hey, Microsoft must have had a problem too, or they would have
 * fixed the LABEL command to allow you to change the serial number.
 *
 * This program COPYRIGHT 1991 D&N Software. All rights reserved.
 * Written by Dave Newman (213) 947-4878
 * Please do not steal this program by removing this notice!
 * You may distribute the .COM file as you wish but please make this
 * source file available as well.
 * This .C file requires DATALIGHT C to compile. Structure alignment MUST
 * be TURNED OFF (-a switch).
 * This program tests for the extended boot record signature in the boot
 * record. It will not write to any disk unless the formatter provides that
 * extended boot record. (DOS 4.X+)
 * The DOS ERRORLEVEL will be set to 0 on a valid exit. 1 on ERROR.
 */

#include <stdio.h>
#include <stdlib.h>
#include <dos.h>
/* #define DEBUG */

struct boot_sector
		{
		char stuff[38];					/* not important to us in this program */
		char ext_boot;					/* extended boot signature (0x29) */
		int vol_se1;						/* This is what we want! */
		int vol_se2;						/* This also */
		}

main(int argc,char *argv[])
	{
	struct boot_sector *b_rec;
	char boot_buffer[512];
	char vs_string[80];
	char vs_start[5];
	char vs_end[5];
	int drive = 0;		/* default to "A" drive */

	/* get command line */
	if(argc == 2)
		drive = toupper(argv[1][0]) - 65;

	/* read boot sector */
	dos_abs_disk_read(drive,1,0,boot_buffer);
	b_rec = boot_buffer;

	/* test for extended boot signature in boot record */
	if(b_rec->ext_boot != 0x29)
			{
			puts("No Volume Serial Number exists for this disk.");
			exit(1);		/* This is an ERROR exit */
			}
	printf("Volume Serial Number is %04X-%04X\n",b_rec->vol_se2,b_rec->vol_se1);

	/* Query for new serial number */
	printf("\nVolume Serial Number (8 characters, ENTER for none)? ");
	gets(vs_string);

	/* Quit on ENTER alone */
	if(*vs_string==NULL)
			exit(0);						/* This is NOT an error exit! */

	/* parse string into 2 int's */
	vs_string[8]=0;
	strncpy(vs_start,vs_string,4);
	strncpy(vs_end,vs_string+4,4);
	vs_start[4] = 0;
	vs_end[4] = 0;

	/* and place into the boot record */
	b_rec->vol_se2 = atoi(vs_start);
	b_rec->vol_se1 = atoi(vs_end);

#ifdef DEBUG
	printf("\n1== %04X",b_rec->vol_se1);
	printf("\n2== %04X",b_rec->vol_se2);
#endif

	/* now re-write the boot record */
	dos_abs_disk_write(drive,1,0,boot_buffer);

	/* all done! */
	exit(0);
	}
