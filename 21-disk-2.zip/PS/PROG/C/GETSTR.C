/* ------------------------------------------------------------ */
/*      GETSTR.C: String input                                  */
/*      G�rb�z Aslan, 1989-1993                                 */
/*      Version 2.61                                            */
/* ------------------------------------------------------------ */

#include <stdio.h>
#include <dos.h>
#include "keys.h"

typedef unsigned char   _byte;
typedef unsigned short  _word;
typedef unsigned long   _dword;

#define YES     1
#define NO      0

/* Null karakter: Bu karakter '\0' karakteri yerine yorumlanacak
 * olan karakteri g�sterir. _NC_ '\0' �eklinde tan�mlanmazsa veri al�nacak
 * b�lgenin de s�z konusu null karakterle doldurulmas� gerekecektir.
 */
#define _NC_    '\xfa'          /* Null character */

#define MK_FAR(seg,ofs) ((void far *)((unsigned long)(seg)<<16 | (ofs)))

struct CHR {
	char let;
	char atr;
	};

typedef union {
	struct CHR c;
	short n;
	} SCR;

/* ------------------------------------------------------------ */
/*      Baz� fonksiyon ve de�i�kenler ba�ka dosya ya da         */
/*      k�t�phanelerde ayn� isimde de�i�kenler bulunmas�        */
/*      ihtimalini dikkate alarak static olarak tan�mlan-       */
/*      m��lard�r.                                              */
/* ------------------------------------------------------------ */
static _word    _videoseg;
static int      _cursize;
static int      _insert;
static int      _ischg;         /* String de�i�im kontrol flag'� 
				 * String de�i�irse 0 dan farkl� de�er al�r.
				 */

int     _getSTR(char *str, int count, int mode);
int     getSTR(char *str, int count, int (*exfunc)(int), int mode);
void    chk_insert(void);

/* Cursor sat�r�... */
static _byte getrow(void)
{
	union REGS regs;

	regs.h.ah = 3;
	regs.h.bh = 0;
	int86(0x10, &regs, &regs);

	return (_byte)regs.h.dh;
}

/* Cursor s�tunu... */
static _byte getcol(void)
{
	union REGS regs;

	regs.h.ah = 3;
	regs.h.bh = 0;
	int86(0x10, &regs, &regs);

	return (_byte)regs.h.dl;
}

/* Cursor konumland�rma */
static void pos(int row, int col)
{
	union REGS regs;

	regs.h.ah = 2;
	regs.h.bh = 0;
	regs.h.dh = row;
	regs.h.dl = col;
	int86(0x10, &regs, &regs);
}

/* Cursor boyutlar�... */
static int getcursize(void)
{
	union REGS regs;

	regs.h.ah = 3;
	regs.h.bh = 0;
	int86(0x10, &regs, &regs);

	return regs.x.cx;
}

static void setcursize(int cursize)
{
	union REGS regs;

	regs.h.ah = 1;
	regs.x.cx = cursize;
	int86(0x10, &regs, &regs);
}

/* Karakter giri�... */
static int getkb(void)
{
	union REGS regs;

	regs.h.ah = 0;
	int86(0x16, &regs, &regs);

	return regs.x.ax;
}

/* Insert stat�s� kontrol�... */
static void chk_insert(void)
{
	char far *fp = MK_FAR(0x40, 0x17);

	_insert = (*fp & 0x80) ? YES : NO;

	if (_insert)
	    setcursize(0x001F);
	else
	    setcursize(_cursize);
}

/* ------------------------------------------------------------ */
/*      Bu fonksiyon _videoseg de�i�kenine video moda uygun     */
/*      de�eri yerle�tirir. _videoseg de�i�keni video memory    */
/*      adresinin ba�lang�� segment de�erini g�stermelidir.     */
/* ------------------------------------------------------------ */
void setvseg(void)
{
	union REGS regs;

	int86(0x11, &regs, &regs);
	_videoseg = (regs.x.ax & 0x30) == 0x30 ? 0xb000 : 0xb800;
}

static int __getSTR(char *str, int count, int (*exfunc)(int), int n, int mode)
{
	register int row, col;
	SCR far *p;
	SCR far *t;
	SCR far *r;
	char *buf;
	int c, e, g, i, len, firstcol, lastcol, ret;
	static char tmpBuf[128];

	_cursize = getcursize();
	chk_insert();
	p = (SCR far *) MK_FAR(_videoseg, 0);
	row = getrow();
	firstcol = col = getcol();
	lastcol = firstcol + count;
	p += row * 80 + col;
	memcpy(tmpBuf, str, count);
	buf = tmpBuf;
	t = p;
	if (n == 0)
	    n = getkb();
	for (; ;n = getkb()) {
		if (exfunc != NULL) {
			ret = (*exfunc)(n);
			if (ret)
				goto END;
			}

		if (n == CR) break;
		c = (char) n;
		switch (n) {
C_KP6:
			case KP6 :
				if (col < lastcol - 1 && t->c.let != _NC_) {
					t++;
					col++;
					}
				break;
			case KP4 :
				if (col > firstcol) {
					t--;
					col--;
					}
				break;
			case DEL :
				for (r = t, i = col; i < lastcol - 1; ++i)
					r++->c.let = (r + 1)->c.let;
				r->c.let = _NC_;
				_ischg = YES;
				break;
			case  BS :
				if (col == firstcol) break;
				for (r = t, i = col; i < lastcol; ++i) {
					(r - 1)->c.let = r->c.let;
					r++;
					}
				col--;
				t--;
				(r - 1)->c.let = _NC_;
				_ischg = YES;
				break;
			case KP0 :
				chk_insert();
				break;
			case KP7 :
				col = firstcol;
				t = p;
				break;
			case KP1 :
				col = lastcol - 1;
				t = p + count - 1;
				for (; (col >= firstcol) && (!t->c.let || (t->c.let == _NC_)); --t, --col);
				++t; ++col;
				if (col == lastcol) {
					--col;
					--t;
					}
				break;
			default  :
				if (mode == 0) {
				    if (!c)
					break;
				    }
				else if (mode == 1) {
				    if (c == ' ')
					goto C_KP6;
				    if (!isdigit(c))
					break;
				    }
				else {
				    if (!isxdigit(c))
					break;
				    c = toupper(c);
				    }
				if (!c) break;
				_ischg = YES;
				if (_insert) {
					for (e = c, r = t, i = col; i < lastcol; ++i) {
						g = r->c.let;
						r++->c.let = e;
						e = g;
						}
					t->c.let = c;
					if (col < lastcol - 1) {
						col++;
						t++;
						}
					break;
					}
				t->c.let = c;
				if (col < lastcol - 1) {
					t++;
					col++;
					}
			}
		pos(row,col);
		}
END:
	t = p + count - 1;
	buf = tmpBuf + count;
	for (len = count; len > 0; --len) {
		c = t->c.let;
		if (c != _NC_ && c != ' ') break;
		else {
			--t;
			--buf;
			}
		}
	++t;
	for (i = 0; i <= len; ++i)
		*buf-- = t--->c.let;
	tmpBuf[len] = '\0';
	memcpy(str, tmpBuf, count);
	setcursize(_cursize);

	return ret;
}

/* ------------------------------------------------------------ */
/*      _getSTR: Bu fonksiyon verilen karakter dizisine         */
/*              klavyeden girilen bilgiyi yerle�tirir. Veri     */
/*              ENTER tu�una bas�l�nca sona erer.               */
/*                                                              */
/*      str   : Veri al�nacak string                            */
/*      count : Karakter say�s�                                 */
/*      mode  : Veri modu                                       */
/*              0 = string                                      */
/*              1 = integer (0..9)                              */
/*              2 = hexadecimal (0..9, a..f, A..F)              */
/* ------------------------------------------------------------ */
int _getSTR(char *str, int count, int mode)
{
	return __getSTR(str, count, NULL, 0, mode);
}

/* ------------------------------------------------------------ */
/*      getSTR: Bu fonksiyon verilen karakter dizisine          */
/*              klavyeden girilen bilgiyi yerle�tirir. Veri     */
/*              ENTER tu�una bas�l�nca ya da exfunc()           */
/*              fonksiyonu 0 dan farkl� bir de�er al�nca        */
/*              sona erer.                                      */
/*                                                              */
/*      str   : Veri al�nacak string                            */
/*      count : Karakter say�s�                                 */
/*      mode  : Veri modu                                       */
/*              0 = string                                      */
/*              1 = integer (0..9)                              */
/*              2 = hexadecimal (0..9, a..f, A..F)              */
/*      exfunc: Karakter test fonksiyonu. Veri giri�i ENTER     */
/*              tu�undan ba�ka bir tu�la da sonland�r�lmak      */
/*              istenirse o tu� de�eri i�in 0'dan farkl� bir    */
/*              de�er almal�d�r.                                */
/*                      �rnek: Veri giri�i ESC ve F1 tu�lar�    */
/*                      ile de bitirilmek isteniyor.            */
/*                                                              */
/*                      int exfunc(int c)                       */
/*                      {                                       */
/*                              if (c == F1 || c == ESC)        */
/*                                      return c;               */
/*                              return 0;                       */
/*                      }                                       */
/* ------------------------------------------------------------ */
int getSTR(char *str, int count, int (*exfunc)(int), int mode)
{
	return __getSTR(str, count, exfunc, 0, mode);
}

/* ------------------------------------------------------------ */
/*      A�A�IDAK� B�L�M FONKS�YONLARI DENEMEK AMACIYLA          */
/*      YAZILMI�TIR...                                          */
/* ------------------------------------------------------------ */

/* Karakter test fonksiyonu: ESC ya da F10 tu�unda ayr�l... */
int fx(int c)
{
	switch (c) {
		case ESC:
		case F10:
			return c;
		}

	return 0;
}

void main(void)
{
	int i;
	static char str[80];

	setvseg();
	printf("\rString: ");
	for (i = 0; i < 20; ++i)
		putch(_NC_);

	pos(getrow(), 8);
	getSTR(str, 20, fx, 0);

	printf("\n\n");
	for (i = 0; i < 10; ++i)
		printf("%s\n", str);

	exit(0);
}
