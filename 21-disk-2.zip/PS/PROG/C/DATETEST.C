/* ---------------------------------------------------------*/
/*		         DATE                               */
/*	(C) Copyright G�rb�z Aslan & Kaan Aslan 1989        */
/*		     Version 1.25                           */
/* ---------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef unsigned short	word;
typedef unsigned long	dword;

#define _NC_	'_'

#define isleap(y)	(((y) % 4 == 0 && (y) % 100 != 0) || (y) % 400 == 0)

typedef struct _DATE {
	unsigned day:	5;	/* 1 .. 31 */
	unsigned month:	4;	/* 1 .. 12 */
	unsigned year:	7;	/* 0 .. 127 = 1900 .. 2027 */
	} DATE;

int	_yday(unsigned day, unsigned month, unsigned year);
long	diffDATE(DATE *cdt, DATE *odt);
int	DATEcmp(DATE *d1, DATE *d2);
int	atoDATE(char *str, DATE *dt);
char	*_DATEtoa(DATE *dt);
char	*DATEtoa(DATE *dt);
DATE	*DATEcpy(DATE *des, DATE *src, register unsigned nelem);
DATE	*rDATEcpy(DATE *des, DATE *src, register unsigned nelem);
DATE	*newDATE(DATE *dt, long days);
void	yd_toDATE(int yday, DATE *dt);
void	rtoDATE(long relday, DATE *dt);

static char	day_tab[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
char	*_dayS[] = {
	"Pazartesi", "Sal�", "�ar�amba", "Per�embe",
	"Cuma", "Cumartesi", "Pazar"
	};

int _yday(unsigned day, unsigned month, unsigned year)
{
	register int mday, j;

	j = year;
	day_tab[1] = isleap(j) ? 29 : 28;

	for (j = month - 2, mday = 0; j >= 0; --j) {
		mday += day_tab[j];
		}
	mday += day;

	return mday;
}

void yd_toDATE(int yday, DATE *dt)
{
	register unsigned j;
	register int leap;

	j = dt->year;
	day_tab[1] = isleap(j) ? 29 : 28;

	for (j = 0; yday > day_tab[j]; ++j) {
		yday -= day_tab[j];
		}

	dt->day   = yday;
	dt->month = ++j;
}

DATE *DATEcpy(DATE *des, DATE *src, register unsigned nelem)
{
	register short *dp = (short *)des, *sp = (short *)src;

	while (nelem-- > 0)
		*dp++ = *sp++;
	return des;
}

int DATEcmp(DATE *d1, DATE *d2)
{
	if (d1->year != d2->year)
		return (int)((int)d1->year - (int)d2->year);
	if (d1->month != d2->month)
		return (int)((int)d1->month - (int)d2->month);
	if (d1->day != d2->day)
		return (int)((int)d1->day - (int)d2->day);
	return 0;
}

int atoDATE(char *str, DATE *dt)
{
	char *token, *sep = "/.-";
	register int day, month, year;

	if ((token = strtok(str, sep)) != NULL) {
		day = (unsigned) atoi(token);
		if (day < 1 && day > 31)
			return -1;
		dt->day = day;
		}
	else return -1;
	if ((token = strtok(NULL, sep)) != NULL) {
		month = (unsigned) atoi(token);
		if (month < 1 && month > 12)
			return -1;
		dt->month = month;
		}
	else return -1;
	if ((token = strtok(NULL, sep)) != NULL) {
		year = (unsigned) atoi(token);
		dt->year = year < 100 ? year : year - 1900;
		}
	else return -1;
	return 0;
}

char *_DATEtoa(DATE *dt)
{
	static char buf[12];

	if ((dt->day == 0 || dt->day > 31) ||
		(dt->month == 0 || dt->month > 12))
		sprintf(buf, "__/__/__");
	else
		sprintf(buf, "%02u/%02u/%02u", dt->day, dt->month, dt->year);
	return buf;
}

char *DATEtoa(DATE *dt)
{
	static char buf[12];

	if ((dt->day == 0 || dt->day > 31) ||
		(dt->month == 0 || dt->month > 12))
		sprintf(buf, "__/__/____");
	else
		sprintf(buf, "%02u/%02u/%4u", dt->day, dt->month, dt->year + 1900);
	return buf;
}

long relday(unsigned day, unsigned month, unsigned year)
{
	register int i;
	long days;

	days = (long)_yday(day, month, year) + 6;
	for (i = 1; i < year; ++i)
		days += isleap(i) ? 366 : 365;

	return days;
}

void rtoDATE(long relday, DATE *dt)
{
	register int i, j;

	relday -= 6;
	for (i = 1; relday > 0; ++i) {
		j = isleap(i) ? 366 : 365;
		relday -= j;
		}
	relday += j;
	yd_toDATE((int)relday, dt);
}

long diffDATE(DATE *cdt, DATE *odt)
{
	register int i;
	unsigned y1, y2;
	int sign, cdays, odays;
	long days = 0L;

	cdays = _yday(cdt->day, cdt->month, cdt->year + 1900);
	odays = _yday(odt->day, odt->month, odt->year + 1900);

	if (cdt->year > odt->year) {
		sign = 1;
		y2 = cdt->year;
		y1 = odt->year;
		}
	else {
		sign = -1;
		y2 = odt->year;
		y1 = cdt->year;
		}

	for (i = y1; i < y2; ++i)
		days += isleap(i) ? 366 : 365;
	if (sign == 1) days += cdays - odays;
	else days += odays - cdays;
	days *= sign;
	return days;
}

DATE *newDATE(DATE *dt, long days)
{
	long rd;

	rd = relday(dt->day, dt->month, dt->year);
	rd += days;

	rtoDATE(rd, dt);
	return dt;
}

void getcDATE(DATE *dt)
{
	time_t t;
	struct tm *today;

	time(&t);
	today = localtime(&t);
	dt->day = today->tm_mday;
	dt->month = today->tm_mon + 1;
	dt->year = today->tm_year;
}


#if	1

main()
{
	char s[12];
	char *pt;
	int tday, comp;
	long noday;
	DATE tarih1, tarih2;

clrscr();
printf("\nL�tfen gg.aa.yy bi�iminde bir tarih giriniz ");
printf("(Ayra� /.- olabilir) : ");
gets(s);
comp = atoDATE(s, &tarih1);
if (!comp)
	printf("Tarih DATE tipine d�n��t�r�ld� (atoDATE) : %02d/%02d/%02d\n",
tarih1.day, tarih1.month, tarih1.year);
else    {
	printf("Tarih ge�ersiz...\n");
	getch();
	exit(1);
	}

getch();
pt = _DATEtoa(&tarih1);
printf("Tarih tekrar karakter tipine d�n��t�r�ld� (_DATEtoa) : %s\n",
pt);

getch();
pt = DATEtoa(&tarih1);
printf("Tarih bu kez gg/aa/yyyy bi�imine d�n��t�r�ld� (DATEtoa) : %s\n",
pt);

getch();
tday = _yday(tarih1.day, tarih1.month, tarih1.year);
printf("Tarihin bulundu�u y�ldaki ge�en g�n say�s� (_yday) : %d\n",
tday);

getch();
noday = relday(tarih1.day, tarih1.month, tarih1.year);
printf("01/01/1900'den ge�en g�n say�s� (relday) : %ld\n",
noday);

getch();
printf("gg/aa/yy bi�iminde bir tarih daha giriniz : ");
gets(s);
atoDATE(s, &tarih2);
comp = DATEcmp(&tarih1, &tarih2);
if (!comp)
	printf("Tarihler ayn� (DATEcmp)\n");
else
	printf("Tarihler ayn� de�il (DATEcmp)\n");

getch();
noday = diffDATE(&tarih1, &tarih2);
printf("Girdi�iniz iki tarih aras�ndaki g�n fark� (diffDATE) : %ld\n",
noday);

getch();
printf("01/01/1900 den ge�en g�n say�s�n� giriniz : ");
scanf("%ld", &noday);
rtoDATE(noday, &tarih1);
printf("Kar��l�k gelen tarih (rtoday) : %02d/%02d/%02d\n",
tarih1.day, tarih1.month, tarih1.year);

getch();
printf("Bir rakam giriniz : ");
scanf("%ld", &noday);
newDATE(&tarih2, noday);
printf("�kinci girdi�iniz tarihten girdi�iniz g�n kadar sonras� (newDATE) : ");
printf("%02d/%02d/%02d\n", tarih2.day, tarih2.month, tarih2.year);

getch();
getcDATE(&tarih2);
printf("Bug�nk� tarih (getcDATE) : %02d.%02d/%02d\n\n\n",
tarih2.day, tarih2.month, tarih2.year);
printf("KAAN ASLAN\n");
	getch();
}
#endif









