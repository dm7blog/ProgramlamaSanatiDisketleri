#include <io.h>
#include <dos.h>
#include <time.h>
#include <alloc.h>
#include <fcntl.h>
#include <conio.h>
#include <stdio.h>
#include <process.h>
#include <graphics.h>

unsigned char far *Dagta = NULL;
unsigned long lengt;
unsigned char bin2,zozo;

void end(void) // Cikis proseduru
  {
  getch();
  closegraph();
  exit(0);
  }

int Modify(void)
  {
  long step,r,start=0,hobo;

  setviewport(0,0,639,256,1);    // Ekran penceresi tanimlama
  getche();
  step=8;                       // Zoom orani = 8

  while (1)
   {
  clearviewport();              // Ekran sil
  if ((lengt-start)/step>640) hobo=640; else hobo=(lengt-start)/step; // Ekranda gosterilecek kismi hesapla
    for (r=0; r<hobo; r++)
      {
      bin2=Dagta[start+(r*step)];      // Datayi bul
      lineto(r,bin2/2);                // Ekrana ciz
      }
    gotoxy(1,23); printf("%6lu/%6lu zoom:%lu\n",start,lengt,step); // Baslangic noktasini, tum datanin uzunlugunu ve zoom oranini yaz
    zozo=getche();   // Tus kontrolu
    if ((zozo=='+')&&(hobo==640)) start+=640*step;  // Ileri
    if ((zozo=='-')&&((long)(start)>0)) {start-=640*step;if (start<0) start=0;} // Geri
    if (zozo=='1') {step=1;start=0;} // Zoom oranini degistirme
    if (zozo=='2') {step=2;start=0;}
    if (zozo=='3') {step=4;start=0;}
    if (zozo=='4') {step=8;start=0;}
    if (zozo=='q') return 1;         // Cikis icin 'q' tusu
   }
  }

void achafiza(char *filename)
  {
  int zart;
  unsigned int bos,Addr;

  if ((zart=open(filename, O_RDONLY | O_BINARY)) == -1)   // Dosyayi ac
    {
    perror("Dosya hatasi");
    end();
    }
  if ((lengt=filelength(zart)) > 65535L)
   {
   bos = allocmem(0xFFFF,&Addr);                         // Hafiza al
   printf("Boshafiza : %lu, %lu\n",(long)(bos+1)*16,farcoreleft());
   if (lengt/16 > (bos+1)) 		   // Dosya uzunlugu alinir
     {                                     // ve bos hafiza kontrolu
     printf("\n Hafiza yetmedi %lu icin %lu'da\n",lengt,(long)(bos+1)*16);
     end();
     }
   if ((int)(bos = allocmem(lengt/16-1, &Addr)) != -1)
     {printf("\n Hafiza alma hatasi.\n"); return;}
     if (Addr == 0) {printf("\n Hafiza alma hatasi.\n"); end();}
     //Yer ayir

   Dagta = (unsigned char *) MK_FP(Addr, 0);  //Bir degisken ata
   printf("Segment  : %p\n",Addr);
   }
  else
   {
   // Heap'de hafiza ayirma
   if (!(Dagta = (unsigned char far *) new char[lengt])) {
    printf("\n Hafiza yetmedi\n");
    end();
    }
   }

  read(zart,(void *)Dagta,lengt); //Dosyayi okuma
  close(zart);

  bos = allocmem(0xFFFF,&Addr);
  printf("Bos hafiza : %lu, %lu\n",(long)(bos+1)*16,farcoreleft());

  while(Modify()==2) clearviewport(); // Cizim fonksiyonunu cagir
  closegraph();                       // Ekrani kapat

  if (lengt > 65535L)
   {
   if (freemem(Addr)==-1) // Hafizayi bosalt (C)
     {
     perror("\n Hafiza bosaltma hatasi ");
     }
   }
  else
   {
   delete Dagta;          // Hafizayi bosalt (CPP)
   }
  }

void main(int argu, char *filename[])
  {
  int gdriver=VGA,gmode=VGAHI,errorcode;

  if (argu!=2) {printf("\n Kullanim :\n   PCB dosyaismi\n\n");return;}

  initgraph(&gdriver, &gmode,""); //640x480x16

  if ((errorcode=graphresult()) != grOk)  /* hata */
   {
   printf("Grafik hatasi: %s\n", grapherrormsg(errorcode));
   printf("Cikmak icin bir tusa basin:");
   getch();
   return;
   }

  printf("\n%s\n",filename[1]);
  achafiza(filename[1]);
  }
