#include <stdlib.h>
#include <stdio.h>
#include <process.h>
#include <dir.h>
#include <string.h>
#include <fstream.h>
#include <iostream.h>
#include <stdarg.h>


enum boolean{false,true};
char sur[MAXDRIVE],dir[MAXDIR],ad[MAXFILE],soy[MAXEXT];
char *winchar="������������";   // karakterlerin bire bir
char *doschar="������������";   // kar��l�klar�..

void Yardim(int no,...)
{
va_list yar;
char *a1,*a2;
        va_start(yar, no);
        a1=va_arg(yar, char*);
        a2=va_arg(yar, char*);
        va_end(yar);
        switch(no){
                case 0:cout << "\nPrizma, Amateur programmers group 1994. Recep Tezkol\n";
                       cout << "WD Utility - Windows / DOS T�rk�e Karakter �evirici.\n\n";
                       break;
                case 1:cout << "                     ** YARDIM **\n";
                       cout << "  Kullan�m:  WD [-se�enek] <kaynak dosya> [hedef dosya]\n";
                       cout << "se�enekler:\n";
                       cout << "             -W   Windows'tan DOS'a\n";
                       cout << "             -D   DOS'tan  Windows'a\n";
                       cout << "Se�enek belirtilmez veya yanl�� verilirse dosyay� inceleyerek\n";
                       cout << "do�rusunu bulur. �evrilecek karakter yoksa i�lem yapmaz.\n";
                       break;
                case 2:cout << "Dosya inceleniyor...\n";
                       break;
                case 3:cout << "Dosyada �evirilecek karakter bulunamad�.\n";
                       break;
                case 4:cout << "Windows'tan DOS'a d�n��t�r�l�yor..\n";
                       break;
                case 5:cout << "DOS'tan Windows'a d�n��t�r�l�yor..\n";
                       break;
                case 6:cout << "�zg�n�m " << a1 << " a��lam�yor.\n";
                       break;
                case 7:cout << "�ans�n�za k�s�n " << a2 << " yarat�lam�yor..\n";
                       break;
                case 8:cout << a1 << " -> " << a2 << " olarak kopyaland�..\n";
                       break;
                }
}


void ExtChg(char *Path,char *newext)
{
        fnsplit(Path,sur,dir,ad,soy);
        fnmerge(Path,sur,dir,ad,newext);
}

class Dosya{
public:
        char *dosya_adi;
        virtual char cevir(char c)              { return c;}
};


class WinFile:public Dosya{
public:
        WinFile(char *isim) { dosya_adi=isim;}
        char cevir(char c);
};
char WinFile::cevir(char c)
{
int x;
        for(x=0;x<12;x++) if(*(winchar+x) == c) return *(doschar+x);
        return c;
}

class DosFile:public Dosya{
public:
        DosFile(char *isim) { dosya_adi=isim;}
        char cevir(char c);
};
char DosFile::cevir(char c)
{
int x;
        for(x=0;x<12;x++) if(*(doschar+x) == c) return *(winchar+x);
        return c;
}

int arastir(char *name)
{
WinFile w(name);
DosFile d(name);
char ch,c;
boolean wi=false,ds=false;
ifstream ky;
        Yardim(2);
        ky.open(w.dosya_adi,ios::nocreate);
        if(!ky) return 4;
        while (ky.get(ch)){
                c=ch;
                c=w.cevir(ch);
                if(c!=ch) wi=true;
                c=d.cevir(ch);
                if(c!=ch) ds=true;
                if(wi || ds) break;
                }
        ky.close();
        if(wi) return 1;
        if(ds) return 2;
        return 3;
}

int Kopya(Dosya *a,Dosya *b)
{
ifstream ky;
ofstream hd;
char     ch,c;
boolean  durum=false;

        ky.open(a->dosya_adi,ios::nocreate);
        if(!ky) return 2;
        hd.open(b->dosya_adi);
        if(!hd) return 3;
        while (hd && ky.get(ch)){
                c=ch;
                ch=a->cevir(ch);
                if(c!=ch) durum=true;
                hd.put(ch);
                }
        ky.close();
        hd.close();
        if(!durum){
                unlink(b->dosya_adi);
                return 0;
                }
        return 1;
}


void main(int paramcount,char *paramstr[])
{
Dosya   *kaynak,*hedef;
char    girdi[MAXPATH],cikti[MAXPATH];
char    secenek;
boolean snk=false;
        Yardim(0);
        switch(paramcount){
                case 1: Yardim(1);
                        exit(-1);
                case 2: strcpy(girdi,paramstr[1]);
                        strcpy(cikti,paramstr[1]);
                        ExtChg(cikti,".$xt");
                        break;
                case 3: if(*paramstr[1]=='-'){
                                secenek=*(paramstr[1]+1);
                                strcpy(girdi,paramstr[2]);
                                strcpy(cikti,paramstr[2]);
                                ExtChg(cikti,".$xt");
                                snk=true;
                                }
                        else    {
                                strcpy(girdi,paramstr[1]);
                                strcpy(cikti,paramstr[2]);
                                }
                         break;
                case 4:if(*paramstr[1]=='-'){
                                secenek=*(paramstr[1]+1);
                                strcpy(girdi,paramstr[2]);
                                strcpy(cikti,paramstr[3]);
                                snk=true;
                                }
                        else    {
                                strcpy(girdi,paramstr[1]);
                                strcpy(cikti,paramstr[2]);
                                }
                        break;
                }


dongu:;
        if(snk){
                switch(secenek){
                        case 'w':
                        case 'W':
                                 kaynak=new WinFile(girdi);
                                 hedef=new DosFile(cikti);
                                 Yardim(4);
                                 break;
                        case 'd':
                        case 'D':
                                 kaynak=new DosFile(girdi);
                                 hedef=new WinFile(cikti);
                                 Yardim(5);
                                 break;
                        default: snk=false;
                                 goto dongu;
                        }
                }
        else    {
                switch(arastir(girdi)){
                        case 1:snk=true;
                               secenek='W';
                               goto dongu;
                        case 2:snk=true;
                               secenek='D';
                               goto dongu;
                        case 3:Yardim(3);
                               exit(-1);
                        case 4:Yardim(6,girdi);
                                exit(-1);
                        }
                }


        switch(Kopya(kaynak,hedef)){
                case 0: snk=false;
                        goto dongu;
                case 1: Yardim(8,girdi,cikti);
                        break;
                case 2: Yardim(6,girdi);
                        break;
                case 3: Yardim(7,cikti);
                        break;
                }
        delete kaynak;
        delete hedef;
}