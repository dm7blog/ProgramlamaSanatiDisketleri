#include <bios.h>
#include <stdio.h>
#include <stdlib.h>
#include <dos.h>
typedef unsigned char byte;
typedef unsigned int  word;

byte DISKBASE[11] ={0xDF,2,0x25,2,0,0x1b,0xFF,0x28,0,0xF,8,};
byte SA[72]={0,0,1,2,0,0,2,2,0,0,3,2,0,0,4,2,0,0,5,2,0,0,6,2,
	   0,0,7,2,0,0,8,2,0,0,9,2,0,0,10,2,0,0,11,2,0,0,12,2,
	   0,0,13,2,0,0,14,2,0,0,15,2,0,0,16,2,0,0,17,2,0,0,18,3};


void interrupt (*eskitablo)();
byte tampon[512];


byte iz_sec()
{
int sonuc;
	sonuc = biosdisk(2,0,0,0,1,1,tampon);
	if(sonuc==0){
		switch(tampon[21]){
			case 0xf0: return 18;
			case 0xf9: if(tampon[24]==15) return 15;
					else return 9;
			case 0xfd: return 9;
			}
		}
return 0;
}


void format(byte trk,byte yan,byte scr)
{
byte x;
word a,b;
	for(x=0;x<scr;x+=4){
		SA[x]=trk;
		SA[x+1]=yan;
		}
	for(x=0;x<5;x++){
		b=0x90;
		a=peekb(0,b);
		a&=0xdf;
		a|=7;
		pokeb(0,b,a);
		_DL=0;
		_DH=yan;
		_CL=1;
		_CH=trk;
		_BX=FP_OFF(SA);
		_ES=FP_SEG(SA);
		_AL=scr;
		_AH=5;
	  asm{  int 13h }
		if(_AH) {
			_AX=0;
			_DL=0;
			asm{  int 13h }
			}
		 else break;
		}
}

void main()
{
byte sector;
int x;
	printf("\n\n\tPSAD-Programlama Sanat� Anahtar Disket haz�rlay�c�\n");
	printf("\t\t  Recep Tezkol.  24 Nisan 1995\n");
	printf("\tAyr�nt�l� bilgi i�in PSAD.TXT dosyas�n� okuyunuz..\n");
	printf("\n\nANAHTAR D�SKET yap�lacak disketi A: s�r�c�s�ne tak�p bir tu�a bas�n�z\n");
	x=getch();
	sector=iz_sec();   	//track ba��na d��en sector say�s�n� bulur
				//bunu boot'un 25. byte'�ndan al�r.
	if(sector!=18) {
		printf("disket HD 3.5 inc olmal�..\n");
		exit(1);
		}
	DISKBASE[4]=sector;      //ve disket parametre tablosuna yazar.
	eskitablo=getvect(0x1e); //disket par. tablosu saklan�r.
	poke(0,(0x78+2),FP_SEG(DISKBASE)); //C'de bunu setvect ile yapamad�m.
	poke(0,0x78,FP_OFF(DISKBASE));     //interrupt vector tablosuna
					  //yeni tablonun adresini b�rak�yor.
	pokeb(0x40,0x90,0x57);
	pokeb(0x40,0x8b,0x57);
	pokeb(0x40,0x41,0);
	format(80,1,sector);		//kullan�lmayan 80.iz formatlan�yor
					//bu izin son sektoru 1024 byte'l�k
	setvect(0x1e,eskitablo);        //eski tablo yerine iade ediliyor.

	printf("A�a��daki seri numaralar� kontrol i�in saklay�n�z.\n");
	printf("--------------------------------------------------\n");
	randomize();
	for(x=0;x<10;x++){
		tampon[x]=rand();
		printf("%d=",(byte)tampon[x]);
		}
	printf("\n");
	biosdisk(3,0,1,80,1,1,tampon);
}

