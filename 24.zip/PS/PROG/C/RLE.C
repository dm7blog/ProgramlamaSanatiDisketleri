#include <stdio.h>
#include <conio.h>
#include <mem.h>

int main(void);
int uncompress(unsigned char *in_array,int in_size,unsigned char *out_array);
int compress(unsigned char *in_array,int in_size,unsigned char *out_array);
int process_comp(unsigned char *in_array,int i,int in_size);
int process_uncomp(unsigned char *in_array,int i,int in_size);

unsigned char screen[22] = {"fffffffdfsdfffffffdddd"};
unsigned char new[2000];

/********--------main-----------********/
int main()
{
    int orig_length=22;
    int compressed_length;
    int i;

compressed_length=compress(screen,orig_length,new);
printf("\nOriginal screen (%d) compressed to %d bytes\n",orig_length,compressed_length);
orig_length=uncompress(new,compressed_length,screen);
printf("\nAnd back to the original (%d) length\n",orig_length);

  for(i=0;i<orig_length;i++)
        printf("%c",screen[i]);
  return(0);
}

/********--------compress-----------********/
int compress(unsigned char *in_array,int in_size,unsigned char *out_array)
{
   register int i=0;
   register int j=0;
   register int k;
   register int l;

while(i<in_size) {
  if (in_array[i]==in_array[i+1] && in_array[i+1]==in_array[i+2]) {
     k=process_comp(in_array,i,in_size);
        out_array[j++]=(unsigned char)k | 0x80;
        out_array[j++]=in_array[i];
        i+=k;
        }
        else {
           k=process_uncomp(in_array,i,in_size);
           out_array[j++]=(unsigned char)k;
           for(l=0;l<k;l++)
                out_array[j++]=in_array[i++];
        }
  }
  return(j);
}

/********--------process_comp-----------********/
int process_comp(unsigned char *in_array,int i,int in_size)
{
   register int len=0;

   while(in_array[i]==in_array[i+1] && i<in_size) {
        len++;
        i++;
        if (len==126) break;
   }
   return(len+1);
}

/********--------process_uncomp-----------********/
int process_uncomp(unsigned char *in_array,int i,int in_size)
{
   register int len=0;

   while((in_array[i]!=in_array[i+1] ||
                in_array[i]!=in_array[i+2]) && i<in_size) {
        len++;
        i++;
        if (len==127) break;
   }
   return(len);
}

/********--------uncompress-----------********/
int uncompress(unsigned char *in_array,int in_size,unsigned char *out_array)
{
   register int i=0;
   register int j=0;
   register int k=0;
   register int l;

   for(i=0;i<in_size;) {
        j=in_array[i++];
        if (j>128) {
           for(j-=128;j>0;j--)
                out_array[k++]=in_array[i];
           i++;
        }
        else
           for(l=0;l<j;l++)
                out_array[k++]=in_array[i++];
   }
   return(k);
}