#include <dos.h>
#include <stdio.h>
typedef unsigned char byte;

byte kontrol(a1,a2,a3,a4,a5,a6,a7,a8,a9,a0)
byte a1,a2,a3,a4,a5,a6,a7,a8,a9,a0;
{
byte tampon[512];
byte x;
	x=biosdisk(2,0,1,80,1,1,tampon);
	x=biosdisk(2,0,1,80,1,1,tampon);
	if(x>0) return 1;
	if(tampon[0]==a1) if(tampon[1]==a2) if(tampon[2]==a3)
	if(tampon[3]==a4) if(tampon[4]==a5) if(tampon[5]==a6)
	if(tampon[6]==a7) if(tampon[7]==a8) if(tampon[8]==a9)
	if(tampon[9]==a0) {
		x=biosdisk(4,0,1,80,18,1,tampon);
		if(x==4) return 0;
		}
return 1;
}


void main()
{

	/* 
	  kontrol fonksiyonuna aktar�lan de�erler-bunlar 10 tanedir-
	  psad taraf�ndan disket haz�rland�ktan sonra verilen 
	  de�erlerdir.
	  a�a��daki de�erlerin hayali oldu�unu s�ylememe gerek yok san�r�m.
	*/	
if(kontrol(86,139,251,69,41,227,138,11,54,159)>0){
	printf("Bu program i�in anahtar disket gereklidir.\n");
	}
	else printf("program �al���yor.\n");
}



