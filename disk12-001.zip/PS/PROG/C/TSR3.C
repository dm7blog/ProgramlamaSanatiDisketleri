/* A�a��da belli bir zamanda sistemi reset eden TSR �rne�i verilmi�tir.
 * Bu �rnek e�itim ama�l� olarak d�zenlenmi�tir. �e�itli optimizasyonlar
 * okuyucuya b�rak�lm��t�r.
*/

#include <stdio.h>
#include <dos.h>
#include <string.h>

long elapsed_time;

char far *vp = (char far *) 0xb8000000;
long far *tick = (long far *) 0x0040006c; /* timer tick */
char s[10];

void interrupt (*old8)(void);
void  (far *rst) (void) = (void ( far *) (void) ) 0xffff0000;

void _writec(int row, int col, int ch)
{
	char far *scrp = vp;
	scrp += row * 160 + col * 2;
	*scrp = ch;

}

void _writes(int row, int col, char *str)
{
	char far *scrp = vp;
	scrp += row * 160 + col * 2;

	while (*str != NULL)
	{
		*scrp = *str++;
		scrp += 2;
	}
}

void argcheck(int argc, char *argv[])
{
        if (argc < 2)
	{
		printf("reset zaman�n� griniz...\n");
		exit(1);
	}
	if (atoi(argv[1]) > 23)
	{
		printf("Ge�ersiz zaman...\n");
		exit(1);
	}
	if (argv[1][2] != ':' || argv[1][5] != ':')
	{
		printf("Ge�ersiz zaman...\n");
		exit(1);
	}
	if (atoi(argv[1]+3) > 59)
	{
		printf("invalid time...\n");
		exit(1);
	}

	if (atoi(argv[1]+6) > 59)
	{
		printf("invalid time...\n");
		exit(1);
	}
	puts("Reset TSR y�klendi...");
}

void interrupt new8(void)
{
	if (*tick == elapsed_time)
		rst();
	old8();

}

main(int argc, char *argv[])
{

	int hour, min, sec;
	char *p;

	argcheck(argc, argv);
	p = argv[1];

	while (*p != NULL)
		++p;

	p = p-2;
	sec = atoi(p);
	p = p - 3;
	min = atoi(p);
	p = p-3;
	hour = atoi(p);

	elapsed_time = (sec+hour+min) * 182L/10L + min * 60 + hour * 3600L;

	old8 = getvect(0x8);
	setvect(0x8, new8);
	keep(1, 3000);
}
