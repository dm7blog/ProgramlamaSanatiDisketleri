/* A�a��da bas�lan tu� say�s�n� ekranda g�steren bir TSR �rne�i verilmi�tir
*/

#include <stdio.h>
#include <dos.h>
#include <string.h>

#define SH_F10  0x5D00


void interrupt (*oldint9) (void);
char s[10];

void _writes(int row, int col, char *str)
{
	char far *scrp = (char far *) 0xb8000000;
	scrp += row * 160 + col * 2;

	while (*str != NULL)
	{
		*scrp = *str++;
		scrp += 2;
	}
}

int get_last_buffer(void)
{
	char far *t1 = (char far *) 1050;

		if (*t1 != *(t1+2))
		{
			t1 += *t1 - 26;
			return *(int far *) t1;
		}
	return 0;
}

void interrupt newint9(void)
{
	static int x = 1;
	static int ch;

	oldint9();
	ch = get_last_buffer();

	if (ch)
	{
		itoa (x, s, 10);
		_writes(0, 74, s);
		++x;
	}
	if (ch == SH_F10)
	{
		setvect(0x9, oldint9);
		freemem(_psp);
	}
}


main()
{
	printf("TSR y�klendi...\n");
	oldint9 = getvect(0x09);		/* ger�ek 9h saklan�yor */
	setvect(0x9, newint9);			/* 9h yerine newin9 �a��r�lacak */
	keep(0, 500);					/* 5000 * 16 byte bellekte kalacak */
}