/* A�a��daki ekrana saati ��karan TSR program� e�itim amac�yla
 * olduk�a a��k bir bi�imde yaz�lm��t�r. �e�itli optimizasyonlar ve
 * d�zeltmeler okuyucuya b�rak�lm��t�r.
 */

#include <stdio.h>
#include <dos.h>
#include <string.h>

void interrupt (*oldint8) (void);
void interrupt (*oldint9) (void);
int ch;

#define SH_F10	0x5D00

long far *tick = (long far *) 0x0000046c;	/* timer tick */
char s[10] = {0,0,':',0,0,':',0,0,0,0};
long total_sec;
int sec, min, hour;

void _writes(int row, int col, char *str)
{
	char far *scrp = (char far *) 0xb8000000;
	scrp += row * 160 + col * 2;

	while (*str != NULL)
	{
		*scrp = *str++;
		scrp += 2;
	}
}

int get_last_buffer(void)
{
	char far *t1 = (char far *) 1050;

		if (*t1 != *(t1+2))
		{
			t1 += *t1 - 26;
			return *(int far *) t1;
		}
	return 0;
}

void f1(int a, char *str)
{
	str[0] = a / 10 + '0';
	str[1] = a % 10 + '0';
}

void interrupt newint8(void)
{
	oldint8();

	total_sec = *tick * 10 / 182;
	sec = total_sec % 60L;
	min = total_sec % 3600L / 60;
	hour = total_sec / 3600;

	f1(hour, s);
	f1(min, s+3);
	f1(sec, s+6);

	_writes(0, 72, s);
}

void interrupt newint9(void)
{
	oldint9();

	ch = get_last_buffer();

	if (ch == SH_F10)
	{
		setvect(0x9, oldint9);
		setvect(0x8, oldint8);
		freemem(_psp);
	}

}

main()
{
	printf("TSR y�klendi\n...");
	oldint8 = getvect(0x08);
	oldint9 = getvect(0x09);
	setvect(0x8, newint8);
	setvect(0x9, newint9);
	keep(0, 500);
}