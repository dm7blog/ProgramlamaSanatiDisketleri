/*klavye.c (Michael O'Connor/PC WORLD) */

#include <ctype.h>
#include <dos.h>
#include <stdio.h>
#include <stdlib.h>
#define ISIN(l,h,v) ((l<=v)&&(v<=h))

int kbdelay=0;  /*Normal (default) yaz�m gecikmesi */
int kbrepeat=0; /*Normal (default) tekrar h�z�     */

void usage(void)
{
        puts("HATA:Men� i�in KLAVYE M yaz\n");
        exit(1);
}

void menu(void)
{
        clrscr();
        puts("\n\t\t\tKLAVYE MENU:\n\n"
             "\t klavye GEC�KME zaman� == gecikme msecs olarak\n"
             "\t        A      ==     250\n"  
             "\t        B      ==     500\n"  
             "\t        C      ==     750\n"  
             "\t        D      ==    1000\n"  
             "\t klavye TEKRAR h�z� == saniye ba��na karakter\n"                   
             "0 == 30.0\t  8 == 15.0\t 16 == 7.5\t 24 == 3.7\n"
             "1 == 26.7\t  9 == 13.3\t 17 == 6.7\t 25 == 3.3\n"
             "2 == 24.0\t 10 == 12.0\t 18 == 6.0\t 26 == 3.0\n"
             "3 == 21.8\t 11 == 10.9\t 19 == 5.5\t 27 == 2.7\n"
             "4 == 20.0\t 12 == 10.0\t 20 == 5.0\t 28 == 2.5\n"
             "5 == 18.5\t 13 ==  9.2\t 21 == 4.6\t 29 == 2.3\n"
             "6 == 17.1\t 14 ==  8.6\t 22 == 4.3\t 30 == 2.1\n"
             "7 == 16.0\t 15 ==  8.0\t 23 == 4.0\t 31 == 2.0\n"
             "S�zdizim klavye <A..D> <0..31>\n" 
             "Normal ayarlar A 0 (k�sa gecikme, h�zl� tekrar)"); 
             exit(1);
}

void main(int argc,char *argv[])
{
 int i;
        if(toupper(argv[1][0])=='M') menu();
        else for(i=1;i<argc;i++) 
	if(isdigit(*argv[i])) {
                kbrepeat=atoi(argv[i]);
                if(!ISIN('A','D',argv[i][0])) usage();
		kbdelay=argv[i][0]-'A';
                }
        _AX = 0x0305;
        _BH = kbdelay;
        _BL = kbrepeat;
        geninterrupt(0x16);
 }




