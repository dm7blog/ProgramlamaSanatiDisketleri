#include <stdio.h>
#include <fcntl.h>
#include <sys\types.h>
#include <sys\stat.h>
#include <io.h>
#include <share.h>
#include <stdlib.h>
#include <string.h>
#include <dos.h>
#include <share.h>
#include <conio.h>
#include <limits.h>
#include <direct.h>
#include "view.h"

/*
  View directory selection routines
*/

#if VIEW_HAS_DIR

int view_dir( UCHAR *name )
{
  int  err;
  int  c1,c2;
  int  olddrive;
  int  newdrive;
  char *test;
  int  row;
  DIRLIST *dir = NULL;
  DIRLIST *cur = NULL;
  VIEWSAVE *vs;

  vs = view_getsave(VIEW_DIR_ROW     ,VIEW_DIR_COL,
                    VIEW_DIR_HEIGHT+2,VIEW_DIR_WIDTH+2);

  do
    {
    *name = '\0';
    dir   = view_getlist();

    view_attr = GET_STRING;
    view_frame(getcwd(view_line,VIEW_MAX_LINE),
               VIEW_DIR_ROW     ,VIEW_DIR_COL,
               VIEW_DIR_HEIGHT+2,VIEW_DIR_WIDTH+2);

    view_dirdisp( dir );

    row = 0;
    cur = dir;
    err = FALSE;

    do
      {
      view_attr = GET_STRING_CURSOR;
      view_goto(VIEW_DIR_ROW+1+row,VIEW_DIR_COL+1);
      view_puts(cur->line,VIEW_DIR_WIDTH);

      c1 = getch();

      switch( c1 )
        {
        case 0:
          c2 = getch();
    
          switch(c2)
            {
            case CURSOR_DOWN:
              if (cur->next)
                {
                cur = cur->next;
                row ++;
                }
            break;
    
            case CURSOR_UP:
              if (cur->prev)
                {
                cur = cur->prev;
                row --;
                }
            break;
    
            case PGDN:
              for (row = 0,cur=dir; row < VIEW_DIR_HEIGHT && cur->next; row ++,cur = cur->next);
              dir = cur;
              row = 0;
            break;
    
            case PGUP:
              for (row = 0,cur=dir; row < VIEW_DIR_HEIGHT && cur->prev; row ++,cur = cur->prev);
              dir = cur;
              row = 0;
            break;
    
            case HOME:
              for (cur = dir; cur->prev; cur=cur->prev);
              dir = cur;
              row = 0;
            break;
    
            case END:
              for (cur = dir; cur->next; cur=cur->next);
              dir = cur;
              row = 0;
            break;
    
            default:
            continue;
            }
        break;
    
        case RETURN:
          for (c2 = 0; c2 < 13 && cur->line[c2] != ' '; c2 ++);
          cur->line[c2] = '\0';

          if (cur->line[14] == 'd')
            chdir(cur->line);
          else
            {
            strcpy(name,cur->line);
            err = TRUE;
            }

          cur->line[c2] = ' ';
        break;
    
        case ESC:
          err = TRUE;
        break;
    
        default:
          c1 = toupper(c1);

          if (c1 >= 'A' && c1 <= 'Z')
            {
            newdrive = (c1-'A')+1;
            _dos_getdrive(&olddrive);
            _dos_setdrive(newdrive,&c2);

            test = getcwd(NULL,66);

            if (!test)
              _dos_setdrive(olddrive,&c2);
            else
              free(test);

            c1 = RETURN;
            break;
            }

        continue;
        }

      if (row < 0)
        {
        row = 0;
        dir = dir->prev;
        }
      else if (row >= VIEW_DIR_HEIGHT)
        {
        row = VIEW_DIR_HEIGHT-1;
        dir = dir->next;
        }

      view_dirdisp( dir );
      }
    while(c1 != RETURN && c1 != ESC);

    dir = view_freelist( dir );
    }
  while(!err);

  view_putsave(vs);

  if (c1 == ESC)
    return(FALSE);
  else
    return(TRUE);
}


void view_dirdisp( DIRLIST *dir )
{
   int row = 0;

   view_attr = GET_STRING;
   do
     {
     view_goto(VIEW_DIR_ROW+1+row,VIEW_DIR_COL+1);
     if (dir)
       {
       view_puts(dir->line,VIEW_DIR_WIDTH);
       dir = dir->next;
       }
     else
       view_fill(' ',VIEW_DIR_WIDTH);
     row ++;
     }
   while(row < VIEW_DIR_HEIGHT);
}

DIRLIST *view_freelist( DIRLIST *dir )
{
  DIRLIST *cur;

  while( dir->prev ) dir = dir->prev;

  do
    {
    cur = dir; 
    dir = dir->next; 
    free(cur->line);
    free(cur);
    }
  while(dir);

  return(dir);
}


DIRLIST *view_getlist ( void )
{
  int  err;
  struct find_t file;
  DIRLIST *dir = NULL;

  for (err = _dos_findfirst("*.*",_A_SUBDIR,&file); !err ; err = _dos_findnext(&file))
    {
    if (file.attrib & _A_SUBDIR)
      dir = view_addline( dir, &file );
    }

  for (err = _dos_findfirst("*.*",_A_NORMAL,&file); !err ; err = _dos_findnext(&file))
    {
    if (!(file.attrib & _A_SUBDIR))
      dir = view_addline( dir, &file );
    }

  while(dir->prev) dir = dir->prev;

  return(dir);
}

DIRLIST *view_addline(DIRLIST *dir, struct find_t *file)
{
  DIRLIST *cur;

  cur = malloc(sizeof(DIRLIST));
  if (!cur) view_error(1,"VIEW0004");

  cur->line = malloc(VIEW_DIR_WIDTH+1);
  if (!cur->line) view_error(1,"VIEW0005");

  if (dir)
    {
    cur->prev = dir;
    cur->next = NULL;
    dir->next = cur;
    dir       = cur;
    }
  else
    {
    cur->next = NULL;
    cur->prev = NULL;
    dir = cur;
    }

  view_fmtline(cur->line,file);

  return(dir);
}

void view_fmtline(UCHAR *line, struct find_t *file)
{
  int idx;
  UCHAR *tmp;

  for (idx = 0; idx < VIEW_DIR_WIDTH; idx ++) line[idx] = ' ';
  line[VIEW_DIR_WIDTH] = '\0';

  memmove(line,file->name,strlen(file->name));

  if (file->attrib & _A_SUBDIR) 
    line[14] = 'd';
  else 
    line[14] = ' ';

  memmove(line+17,view_ultoa((ULONG)((file->wr_date  & 0x01E0) >> 5 ),10,2,'0'),2);
  line[19] = '/';
  memmove(line+20,view_ultoa((ULONG)( file->wr_date  & 0x001F       ),10,2,'0'),2);
  line[22] = '/';
  memmove(line+23,view_ultoa((ULONG)(((file->wr_date & 0xFE00) >> 9 )+80),10,2,'0'),2);

  memmove(line+27,view_ultoa((ULONG)((file->wr_time  & 0xF800) >> 11),10,2,'0'),2);
  line[29] = ':';
  memmove(line+30,view_ultoa((ULONG)((file->wr_time  & 0x07E0) >> 5 ),10,2,'0'),2);

  if (!(file->attrib & _A_SUBDIR))
    memmove(line+34,view_ultoa((ULONG)file->size,10,10,' '),10);
}
#endif /* VIEW_HAS_DIR */
