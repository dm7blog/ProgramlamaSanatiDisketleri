#include <stdio.h>
#include <conio.h>
#include <dos.h>
#include <stdlib.h>
#include <string.h>

 union REGS regs;
 struct SREGS segregs;

 struct vesa
 {
  char vesa[4];          // VESA yazisi
  unsigned char secver;  // Ikincil versiyon
  unsigned char mainver; // Ana versiyon
  char far *manifacturer;// Uretici firma
  unsigned long flag;    // Kullanilmiyor
  unsigned far *modes;   // Kartin destekledigi modlar
 } infobuf,*iptr=&infobuf;

 struct vesamod
 {
  unsigned modeflag;        // VESA modu bilgileri
  unsigned char firstflag;  // ilk pencere bilgileri
  unsigned char secflag;    // ikinci pencere bilgileri
  unsigned granularity;     // VESA penceresi hareket orani
  unsigned size;            // VESA penceresi boyu
  unsigned firstseg;        // ilk pencerenin segment adresi
  unsigned secseg;          // ikinci pencerenin segment adresi
  void far *routine;        // video RAM'daki pencere yerini belirten rutinin adresi
  unsigned pixelperline;    // bir satirdaki pixel sayisinin toplam tuttugu byte sayisi
  unsigned x;               // X cozunurlugu
  unsigned y;               // Y cozunurlugu
  unsigned char width;      // text modlari icin karakterlerin X cozunurlugu
  unsigned char height;     // text modlari icin karakterlerin Y cozunurlugu
  unsigned char bitplanes;  // bitplane sayisi
  unsigned char bits;       // pixel basina dusen bit sayisi
  unsigned char memblock;   // hafiza blogu sayisi
  unsigned char memmodel;   // hafiza tipi
  unsigned char memsize;    // hafiza blogu boyutu(KB)
 } modbuf,*mptr=&modbuf;

void main(void)
{

 int a,dum;
 int modeok=0;
 unsigned gran;
 unsigned char ff,sf;
 unsigned char far *ekran;
 unsigned char yaz=0,oku=0;
 char dummy[150];

 regs.h.ah = 0x4F;  /* VESA fonksiyonu */
 regs.h.al = 0x00;  /* 0 no'lu altfonksiyon: SVGA kartinin ozellikleri? */
 segregs.es = FP_SEG(iptr);
 regs.x.di = FP_OFF(iptr);
 int86x(0x10, &regs, &regs, &segregs);
 if (regs.h.ah!=0) {printf("\n Bu grafik karti VESA fonksiyonlarini desteklemez.\n");exit(1);}

 strncpy(dummy,infobuf.vesa,4);
 dummy[4]='\0';

 printf("\n%s: v%d.%d",dummy,infobuf.mainver,infobuf.secver);
 _fstrcpy(dummy,infobuf.manifacturer);
 printf("\nFirma: %s \nDesteklenen modlar:",dummy);

 while (*infobuf.modes!=0xFFFF)
	{printf("\n	        	Mod: %Xh",*infobuf.modes);
	 regs.h.ah = 0x4F;  /* VESA fonksiyonu */
	 regs.h.al = 0x01;  /* 1 no'lu altfonksiyon: VESA modunun ozellikleri? */
	 regs.x.cx = *infobuf.modes;
	 segregs.es = FP_SEG(mptr);
	 regs.x.di = FP_OFF(mptr);
	 int86x(0x10, &regs, &regs, &segregs);
	 for(a=0,dum=1;a<modbuf.bits;a++,dum*=2); // bit sayisindan renk sayisi hesaplaniyor
	 if ((modbuf.modeflag&16)==16) // Mode flag 4. bit modun Grafik/Text oldugunu belirtir
		strcpy(dummy,"Grafik modu"); else strcpy(dummy,"Text modu");
	 printf(" (%dx%d) %d renk %s.",modbuf.x,modbuf.y,dum,dummy);
	 if ((unsigned)*infobuf.modes==0x0101)
		{ modeok=1;
		  gran=modbuf.granularity;
		  ff=modbuf.firstflag;
		  sf=modbuf.secflag;
		}
	 infobuf.modes++;
	}
 if (modeok)
     printf("\n Simdi de 101h no'lu fonksiyonu deneyelim.Bir tusa basin:\n");
 else {
	printf("\n Bu kart 101h'i desteklemiyor.Ama siz mod numarasini degistirip \n programi tekrar compile ederek deniyebilirsiniz.\n");
	exit(1);
      }
 getch();
 regs.h.ah = 0x4F;  /* VESA fonksiyonu */
 regs.h.al = 0x02;  /* 2 no'lu altfonksiyon: VESA modunda ekran acma */
 regs.x.bx = 0x0101;  /* 640x480x256 VESA modu */
 int86x(0x10, &regs, &regs, &segregs);
 if (!((regs.h.ah==0)&&(regs.h.al==0x4f)))
	{ textmode(3);
	  printf("Mod acilmadi");
	  exit(2);
	}
 // Ekran erisim pencerelerinin durumlarina bakalim
 if ((ff&1)==1) // 1. pencere var mi?
    if ((ff&2)==2) // okunuyor mu ?
       oku=0;
    else if ((ff&4)==4) yaz=0;// yaziliyor mu
 if ((sf&1)==1) // 2. pencere var mi?
    if ((sf&2)==2) // okunuyor mu ?
       oku=1;
    else if ((sf&4)==4) yaz=1;// yaziliyor mu

 // Ekrana bisey cizelim, ilk 100 satira enine renkli cizgiler
 ekran=MK_FP(0xA000,0);
 for (dum=0;dum<100;dum++)
	for(a=0;a<640;a++) {*ekran=(unsigned char)dum;ekran++;}

// devam etmek icin sayfa degistiriyoruz
 regs.h.ah = 0x4F;  /* VESA fonksiyonu */
 regs.h.al = 0x05;  /* 5 no'lu altfonksiyon: erisim penceresi degistirme */
 regs.h.bh = 0x00;
 regs.h.bl = yaz;   // ekrana yazim islemi yapiyoruz
 regs.x.dx = (unsigned)(64000U/(gran*1024)); // 640x100 satir ileri (oran'a gore)
 ekran=MK_FP(0xA000,(unsigned)(64000U%(gran*1024))); // fazlaliklari ayarlama
 int86x(0x10, &regs, &regs, &segregs);
 // Isterseniz aradan bu sayfa degistirmeyi kaldirin bakalim altlara pixel
 // koyabiliyormusunuz, koyamiyormusunuz.

 // ikinci 90 satira da renkli cizgiler
 for (;dum<190;dum++)
	for(a=0;a<640;a++) {*ekran=(unsigned char)dum;ekran++;}
// bitti
 getch();
 textmode(3);
 exit(0);
}