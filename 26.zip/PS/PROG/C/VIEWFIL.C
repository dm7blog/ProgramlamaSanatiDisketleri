#include <stdio.h>
#include <fcntl.h>
#include <sys\types.h>
#include <sys\stat.h>
#include <io.h>
#include <share.h>
#include <stdlib.h>
#include <string.h>
#include <dos.h>
#include <share.h>
#include <conio.h>
#include <limits.h>
#include <direct.h>
#include "view.h"

/*
  VIEWFILE access routines
*/

UINT view_getc_bwd( VIEWFILE *vf )
{
   int err;
   UINT ret;
   
#if VIEW_HAS_MEMORY
   if (vf->fh == VIEW_MEM_HDL)
     {
     vf->pos--;
     return(memory[vf->pos]);
     }
   else
     {
#endif
     if (view_tell(vf))
       {
       if (vf->idx == 0)
         {
         view_seek(vf,(-1L),SEEK_CUR);
         ret = vf->buf[vf->idx];
         }
       else
         {
         vf->idx --;
         ret = vf->buf[vf->idx];
         }

       return(ret);  
       }
     else
       return(VIEW_EOF);
#if VIEW_HAS_MEMORY
     }
#endif
}

UINT view_getc_fwd( VIEWFILE *vf )
{
   UINT ret;

#if VIEW_HAS_MEMORY
   if (vf->fh == VIEW_MEM_HDL)
     {
     ret = memory[vf->pos];
     vf->pos ++;
     return(ret);
     }
   else
     {
#endif
     if (vf->idx >= vf->len)
       {
       view_seek(vf,(vf->pos+vf->idx),SEEK_SET);
       if (vf->idx >= vf->len) return(VIEW_EOF);
       }
       
     ret = vf->buf[vf->idx];
     vf->idx ++;
     return(ret);  
#if VIEW_HAS_MEMORY
     }
#endif
}


#if VIEW_HAS_RAW
UINT view_getl_raw( VIEWFILE *vf, UCHAR *line, int dir )
{
    int          num_normal;
    int          num_input;
    int          num_output;
    int          num_fixup;
    UINT ret;
    int          jdx;
    UCHAR         *offset;

    if (vf->lmode == VIEW_BIN_MODE) 
      {
      num_fixup = 11;
      num_input   = VIEW_MAX_BINMODE;
      num_output  = 11+VIEW_MAX_BINMODE;
      }
    else if (vf->lmode == VIEW_HEX_MODE) 
      {
      num_fixup = 60;
      num_input   = VIEW_MAX_HEXMODE;
      num_output  = 11+(num_input*3)+1+num_input;
      }
    else
      return(VIEW_EOF);

    for( jdx = 0; jdx < num_output; jdx ++)
      line[jdx] = ' ';
    line[jdx] = '\0';

    for (ret = num_normal = 0; num_normal < num_input && ret != VIEW_EOF; num_normal ++ )  
      {  
      if (dir)  
        {  
        ret = view_getc_fwd(vf);  

        if (ret != VIEW_EOF)  
          {  
          if (!num_normal)  
            {  
#if VIEW_HAS_MEMORY
            if (vf->fh == VIEW_MEM_HDL)
              offset = view_ultoa((ULONG)(memory+(view_tell(vf)-1L)),16,8,'0');  
            else
#endif
              offset = view_ultoa((view_tell(vf)-1L),10,1,'0');  

            for (jdx = 0; jdx < 11 ; jdx ++)  
              if (*offset) line[jdx] = *(offset++);  
            }  

          if (vf->lmode == VIEW_HEX_MODE)  
            {  
            line[11+num_normal*3]     = hexdigits[ret/16];  
            line[11+num_normal*3+1]   = hexdigits[ret%16];  
            }  

          if (ret) line[num_fixup+num_normal]   = ret;  
          }  
        }  
      else  
        ret = view_getc_bwd(vf);  
      }  
      
    if (!num_normal && ret == VIEW_EOF)
      return(VIEW_EOF);
    else
      return(FALSE);
}
#endif /* VIEW_HAS_RAW */


UINT view_getl_fwd( VIEWFILE *vf, UCHAR *line, int max )
{
    UINT ret;
    int num_normal;
    int new_idx,old_idx;

#if VIEW_HAS_RAW
    if (vf->lmode)
      return(view_getl_raw( vf, line, 1));
#endif

    num_normal = 0;
    new_idx    = 0;
    old_idx    = 0;
    ret = 0;

    while( (ret != VIEW_EOF) && (num_normal < max) )
      {
      ret = view_getc_fwd(vf);

      if (ret == '\n') 
        break;
      else if (ret == '\r')
        continue;
      else if (ret != VIEW_EOF)
        {
        num_normal ++;
        if (new_idx < max) 
          {
          if (ret == TAB)
            {
            old_idx = new_idx;
            new_idx = ((new_idx / 8)*8)+8;
            while(old_idx < new_idx && old_idx < max)
              line[old_idx++] = ' ';
            new_idx = old_idx;
            }
          else if (ret == '\0')
            line[new_idx++] = ' ';
          else
            line[new_idx++] = ret;
          }
        }
      }

    line[new_idx] = '\0';

    if ((ret == VIEW_EOF) && !num_normal)
      return(VIEW_EOF);
    else
      return(FALSE);
}

UINT view_getl_bwd( VIEWFILE *vf, UCHAR *line, int max )
{
    UINT ret;
    int num_newlines;
    int num_normal;
    int new_idx;

#if VIEW_HAS_RAW
    if (vf->lmode)
      return(view_getl_raw( vf, line, 0));
#endif

    num_normal    = 0;
    num_newlines  = 0;
    ret  = 0;

    while ( (ret != VIEW_EOF)  && (num_newlines < 2) && (num_normal < max) )
      {
      ret = view_getc_bwd( vf );

      if ((ret == '\n') || ((num_newlines == 0) && (num_normal == 1)))
        num_newlines ++;
      else if (ret == '\r')
        continue;
      else if (ret != VIEW_EOF)
        num_normal ++;
      }

    if ((ret == VIEW_EOF) && !num_normal)
      ret = VIEW_EOF;
    else if (ret == '\n')
      {
      view_getc_fwd(vf);
      ret = FALSE;
      }
    else
      ret = FALSE;

    return(ret);
}

VIEWFILE *view_open( UCHAR *fname )
{
  int th;
  VIEWFILE *vf;

  vf = malloc(sizeof(VIEWFILE));
  if (!vf) view_error(1,"VIEW0006");

  vf->pos = 0;
  vf->idx = 0;
  vf->len = 0;
  vf->lmode = VIEW_TEXT_MODE;


  if (fname)
    {

#if VIEW_HAS_MEMORY

    if (!stricmp(fname,VIEW_MEM_NAME))
      {
      vf->fh = VIEW_MEM_HDL;
      }
    else

#endif
    if ((vf->fh = open(fname,O_RDONLY|O_BINARY,S_IREAD|S_IWRITE)) < 0)
      {
      view_error(0,"Cannot Open File");
      free(vf);
      return(NULL);
      }
    }
  else
    {
    if (!(th = open("CON",O_RDONLY,S_IREAD|S_IWRITE)))
      view_error(1,"VIEW0007");

    fname     = "Standard Input";

    vf->fh    = dup(fileno(stdin));
    setmode(vf->fh,O_BINARY);
    dup2(th,fileno(stdin));
    }

   if (vf->fh != VIEW_MEM_HDL)
     {
     vf->end = lseek(vf->fh,0L,SEEK_END);
     vf->pos = lseek(vf->fh,0L,SEEK_SET);
     vf->len = read(vf->fh,vf->buf,VIEW_BUF_SIZE);
     vf->pos = lseek(vf->fh,0L,SEEK_SET);
     }

   vf->fname = strdup(fname);
   if (!vf->fname) view_error(1,"VIEW0008");

   return(vf);
}

void view_close( VIEWFILE *vf )
{
   if (vf->fh != VIEW_MEM_HDL)
     close(vf->fh);
   free(vf->fname);
   free(vf);
}


ULONG view_tell( VIEWFILE *vf )
{
  if (vf->fh == VIEW_MEM_HDL)
    return(vf->pos);
  else
    return(vf->pos+vf->idx);
}

ULONG view_seek( VIEWFILE *vf, long pos, int base )
{
  long tpos;
  long rpos;
  int  size;

#if VIEW_HAS_MEMORY
  if (vf->fh == VIEW_MEM_HDL)
    {
    switch( base )
      {
      case SEEK_SET:
      break;

      case SEEK_CUR:
        pos = vf->pos + pos;
      break;
        
      case SEEK_END:
        pos = ULONG_MAX + pos;
      break;
      }

    vf->pos = pos;
    return(pos);
    }
  else
    {
#endif
    switch( base )
      {
      case SEEK_SET:
        tpos = pos;
      break;

      case SEEK_CUR:
        tpos = (((long)vf->pos)+vf->idx)+pos;
      break;

      case SEEK_END:
        tpos = ((long)vf->end)+pos;
      break;
      }

    if (tpos < 0)       
      {
      vf->idx = 0;
      return(0L);
      }

    if (tpos > vf->end) 
      {
      vf->idx = vf->len;
      return(vf->end);
      }

    if (labs(tpos-vf->pos) > VIEW_BUF_SIZE)
      {
      vf->idx = 0;
      vf->pos = lseek(vf->fh,tpos,SEEK_SET);
      vf->len = read(vf->fh,vf->buf,VIEW_BUF_SIZE);
      }
    else if (tpos < vf->pos )
      {
      lseek(vf->fh,vf->pos,SEEK_SET);
      size = (VIEW_BUF_SIZE/4);

      while ( tpos < vf->pos && size )
        {
        if (size > vf->pos) size = vf->pos;

        memmove(vf->buf+size,vf->buf,(VIEW_BUF_SIZE-size));

        vf->len += size;

        if (vf->len > VIEW_BUF_SIZE) 
          vf->len = VIEW_BUF_SIZE;

        lseek(vf->fh,((long)(-size)),SEEK_CUR);

        read(vf->fh,vf->buf,size);

        vf->pos = lseek(vf->fh,((long)(-size)),SEEK_CUR);

        vf->idx = (tpos - vf->pos);
        }
      }
    else if (tpos >= (vf->pos+vf->len))
      {
      rpos = vf->pos + vf->len;

      lseek(vf->fh,rpos,SEEK_SET);
      size = (VIEW_BUF_SIZE/4);

      while ( tpos >= rpos && size )
        {
        if (size > (vf->end-rpos))
          size = (vf->end-rpos);

        if (vf->len > (VIEW_BUF_SIZE-size))
          {
          memmove(vf->buf,vf->buf+size,(VIEW_BUF_SIZE-size));
          vf->len -= size;
          if (vf->len < 0) vf->len = 0;
          }

        read(vf->fh,vf->buf+vf->len,size);

        vf->len += size;
        rpos    += size;
        vf->pos += size;

        vf->idx = (tpos - vf->pos);
        }
      }
    else
      vf->idx = (tpos - vf->pos);
#if VIEW_HAS_MEMORY
    }
#endif
}
