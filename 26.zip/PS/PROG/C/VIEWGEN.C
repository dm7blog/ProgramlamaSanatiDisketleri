#include <stdio.h>
#include <fcntl.h>
#include <sys\types.h>
#include <sys\stat.h>
#include <io.h>
#include <share.h>
#include <stdlib.h>
#include <string.h>
#include <dos.h>
#include <share.h>
#include <conio.h>
#include <limits.h>
#include <direct.h>
#include "view.h"

/*
  View General purpose routines
*/
void view_error( int isfatal,UCHAR *msg )
{
  int col;
  int len;
  VIEWSAVE *save;

  len = max(40,strlen(msg));
  col = 40-(len/2);

  if (!isfatal)
    save = view_getsave(11,col-1,3,len+2);

  view_attr = ERROR_MESSAGE;
  view_frame("Error - Press <ENTER>",11,col-1,3,len+2);
  view_goto(12,col);
  view_puts(msg,len);

  if (!getch()) getch();

  if (isfatal)
    exit(1);
  else
    view_putsave(save);
}

int max( int x, int y)
{
  return(((x < y) ? y : x));
}

int min ( int x, int y)
{
  return(((x < y) ? x : y));
}

#if VIEW_HAS_RAW 
UCHAR *view_ultoa( ULONG num, int base, int wide, int fill )
{
   static char workbuf[VIEW_MAX_LONG];
   int work;
   int idx;

   workbuf[VIEW_MAX_LONG-1] = '\0';

   for (idx = VIEW_MAX_LONG-1; num && idx ;)
     {
     wide --;
     idx  --;
     workbuf[idx] = hexdigits[num%base];
     num /= base;
     }

   while( wide > 0  && idx )
     {
     idx --;
     wide --;
     workbuf[idx] = fill;
     }

   return(workbuf+idx);
}
#endif

#if VIEW_HAS_GOTO
ULONG view_atoul( UCHAR *num, int base )
{
   int idx,jdx;
   ULONG val;

   val = 0;

   while( *num )
     {
     for (jdx = 0; hexdigits[jdx] && hexdigits[jdx] != *num; jdx ++);

     if (!hexdigits[jdx]) break;

     val *= base;
     val += jdx;
     num ++;
     }

   return(val);
}
#endif /* VIEW_HAS_GOTO */
