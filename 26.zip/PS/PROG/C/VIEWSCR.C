#include <stdio.h>
#include <fcntl.h>
#include <sys\types.h>
#include <sys\stat.h>
#include <io.h>
#include <share.h>
#include <stdlib.h>
#include <string.h>
#include <dos.h>
#include <share.h>
#include <conio.h>
#include <limits.h>
#include <direct.h>
#include "view.h"

/*
  View screen and input routines
*/

int view_getvidmode( void )
{
  _asm
      {
      mov ax,0f00h
      int 10h
      xor ah,ah
      }
}

void view_goto(int row,int col)
{
  view_offset = (row*(view_cols*2))+(col*2);
}

void view_putc( int ochar )
{
  int offset = view_offset;

  screen[offset] = ochar;
  offset++;
  screen[offset] = view_attr;
  offset++;

  view_offset = offset;
}

void view_fill(int fill, int count)
{
  while(count > 0) 
    { 
    view_putc(fill);
    count --; 
    }
}

void view_puts(UCHAR *str, int len)
{
  while( *str && len )
    {
    view_putc(*str);
    str ++;
    len --;
    }

  while( len )
    {
    view_putc(' ');
    len --;
    }
}

int view_prompt( UCHAR *title, UCHAR *prompt, UCHAR *retbuf, int retlen )
{
   VIEWSAVE *vs;
   int row,col,width;
   int ret;

   row = (view_rows/2);
   width = strlen(prompt)+1+retlen+2;
   col = (view_cols/2) - width/2;

   vs = view_getsave(row-1,col-1,3,width+2);

   view_attr = GET_STRING;
   view_frame(title,row-1,col-1,3,width+2);
   view_goto(row,col);
   view_puts(prompt,width);

   ret = view_gets(row,col+1+strlen(prompt),retlen,retbuf);

   view_putsave(vs);

   return(ret);
}



int view_gets( int row,int col, int len, UCHAR *str)
{
   int  offset;
   char scan;

   view_attr = GET_STRING;

   offset = 0;

   for(;;)
     {
     view_goto(row,col);
     view_puts(str,len+1);
     view_goto(row,col+offset);
     view_attr = GET_STRING_CURSOR;
     view_puts(str+offset,1);
     view_attr = GET_STRING;

     scan = getch();

     switch( scan )
       {
       case BACKSPACE:
         if (offset > 0)
           {
           offset --;
           str[offset] = '\0';
           }
       break;

       case RETURN:
         str[offset] = '\0';
         return(TRUE);
       break;

       case ESC:
         return(FALSE);
       break;

       case 0:
          scan = getch();
       break;
                                
       default:
         if (scan > 31 && scan < 127)
           {
           if (offset < len)
             {
             str[offset] = scan;
             offset ++;
             str[offset] = '\0';
             }
           }
       break;
       }
     }
}

void view_frame( UCHAR *title,int row,int col,int rows,int cols )
{
  int r;
  int off;
  int mod;
  int wid;
  int offset;

  wid = cols-2;

  view_goto(row,col);
  view_putc('�');
  view_fill('�',wid);
  view_putc('�');
  view_goto(row,col+1);
  view_puts(title,min(wid,strlen(title)));

  view_goto(row+1,col);

  off = ((wid)*2);
  mod = (view_cols*2)-(off+4);

  offset = view_offset;

  for (r = 1; r < rows-1; r ++)
    {
    screen[offset]  = '�';
    offset ++;
    screen[offset]  = view_attr;
    offset ++;
    offset += off;
    screen[offset]  = '�';
    offset ++;
    screen[offset]  = view_attr;
    offset ++;
    offset += mod;
    }

  view_offset = offset;

  view_putc('�');
  view_fill('�',wid);
  view_putc('�');
}

void view_putsave( VIEWSAVE *save )
{
   view_unpackbuf(save->buf,save->row,save->col,save->rows,save->cols);

   free(save->buf);
   free(save);
}  

VIEWSAVE *view_getsave( int row,int col,int rows,int cols )
{
   UCHAR *buf;
   VIEWSAVE *getsave;
   int offset;

   getsave = malloc(sizeof(VIEWSAVE));
   if (!getsave) view_error(1,"view_getsave: alloc getsave");

   getsave->row  = row;
   getsave->col  = col;
   getsave->rows = rows;
   getsave->cols = cols;

   getsave->buf = malloc((rows*(cols*2)));
   if (!getsave->buf) view_error(1,"view_getsave: alloc buf");

   buf = getsave->buf;
   cols *= 2;

   view_goto(getsave->row,getsave->col);

   offset = view_offset;

   for (row = 0; row < rows; row ++)
     {
     for (col = 0; col < cols; col ++)
       {
       *buf = screen[offset];
       offset ++;
       buf ++;
       }
     offset += ((view_cols*2)-cols);
     }

   view_offset = offset;

   getsave->buf = realloc(getsave->buf,view_packbuf(getsave->buf,(rows*cols)));

   return(getsave);
}


int view_packbuf( UCHAR *buf, int size )
{
   UCHAR *from, *to;
   UCHAR count;
   UCHAR idx;

   if (!*buf) *buf = ' ';

   for (count = 0,to = buf,from = buf+2; from-buf < size; from += 2)
     {
     if (!*from) *from = ' ';

     if (((*from == *(from-2)) && (*(from+1) == *(from-1))) && (count < 255))
       count ++;
     else if (count > 4)
       {
       *(to++) = '\0';
       *(to++) = count;
       *(to++) = *(from-2);
       *(to++) = *(from-1);
       count = 0;
       }
     else
       {
       for (idx = 0; idx <= count; idx ++)
         {
         *(to++) = *(from-2);
         *(to++) = *(from-1);
         }
       count = 0;
       }
     }

   if (count > 4)
     {
     *(to++) = '\0';
     *(to++) = count;
     *(to++) = *(from-2);
     *(to++) = *(from-1);
     count = 0;
     }
   else
     {
     for (idx = 0; idx <= count; idx ++)
       {
       *(to++) = *(from-2);
       *(to++) = *(from-1);
       }
     count = 0;
     }

   return(to-buf);
}

void view_unpackbuf( UCHAR *buf, int row, int col, int rows, int cols )
{
   UCHAR count,idx;
   UCHAR chr,atr;
   int   ccol;

   view_goto(row,col);

   rows = row+rows;
   cols = col+cols;
   ccol = col;

   while( row < rows )
     {
     if (!*buf)
       {
       count = *(buf+1);
       chr   = *(buf+2);
       atr   = *(buf+3);
       buf   += 4;
       }
     else
       {
       count = 0;
       chr   = *(buf);
       atr   = *(buf+1);
       buf   += 2;
       }

     for (idx = 0; idx <= count; idx ++)
       {
       screen[view_offset] = chr;
       view_offset ++;
       screen[view_offset] = atr;
       view_offset ++;
       ccol ++;
       if (ccol >= cols)
         {
         ccol = col;
         row  ++;
         view_goto(row,ccol);
         }
       }
     }
}

       

