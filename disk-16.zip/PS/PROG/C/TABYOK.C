#include <stdio.h>
#include <dir.h>
#include <string.h>

typedef struct Pth{
        char sur[DRIVE];
        char dir[DIRECTORY];
        char ad[FILENAME];
        char soy[EXTENSION];
        }Pth;

FILE *Kd;
FILE *Hd;
char cikti[64];
Pth  P;

void hata(int hatano)
{
    switch(hatano){
        case 1:printf("kaynak dosya a�ilamadi.\n");
                exit(-1);
        case 2:printf("Hedef dosya yaratilamadi.\n");
                fclose(Kd);
                exit(-1);
        case 3:printf("Kullanim: TabYok <kaynak dosya> [hedef dosya]\n");
                exit(-1);
        }
}

void main(int paramcount,char *paramstr[])
{
char kar,karboy;
unsigned int i,z,tt=0;
        printf("\nTABYOK - Text dosyada tab yokedici.\n");
        printf("Prizma programcilik (c) 1994. Recep Tezkol.\n\n");

        switch(paramcount){
                case 2: strcpy(cikti,paramstr[1]);
                        fnsplit(cikti,P.sur,P.dir,P.ad,P.soy);
                        fnmerge(paramstr[1],P.sur,P.dir,P.ad,".BAK");
                        rename(cikti,paramstr[1]);
                        printf("%s -> %s\n",strupr(cikti),strupr(paramstr[1]));
                        break;
                case 3: strcpy(cikti,paramstr[2]);
                        printf("%s -> %s\n",strupr(paramstr[1]),strupr(cikti));
                        break;
               default: hata(3);
                }

        if((Kd=fopen(paramstr[1],"r+t"))==NULL) hata(1);
        if((Hd=fopen(cikti,"w+t"))==NULL) hata(2);

        for(;;){
                tt++;
                kar=getc(Kd);
                if(kar==EOF) {
                                putc(26,Hd);
                                break;
                                }
                if(kar=='\n') tt=0;
                if(kar=='\t'){
                        tt--;
                        if(tt!=0){
                        z=((tt & 0xfff8)+8)-tt;
                        }
                        else z=8;
                        tt+=z;
                        for(i=1;i<=z;i++) putc(' ',Hd);
                        }
                else putc(kar,Hd);

                }
        fclose(Kd);
        fclose(Hd);
printf("%s dosyasi tab karakterlerinden temizlendi.\n",strupr(cikti));
}

