// Windows-DOS Turkce karakter problemi yuzunden Turkce yazilar �ngilizce
// fontla yazilmistir. Ayrica programi yazarken buyuk katkisi olan Murat
// Kipel'e tesekkur ederim.

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <fcntl.h>
#include <io.h>
#include <dos.h>
#include <mem.h>

typedef  unsigned char BYTE;
typedef  unsigned int  WORD;

typedef struct {
       BYTE pcx_id;            /* PCX dosylari icin herzaman 0x0A */
       BYTE version;           /* PCX dosyasinin versiyonu */
       BYTE encoding;          /* 1 = RLE (RLL) sikistirma yontemi */
       BYTE bpp;               /* Pixel(nokta) basina dusen bit sayisi */
       WORD upleftx,uplefty;   /* sol ust kosenin kordinati */
       WORD lorightx,lorighty; /* sag alt kosenin kordinati */
       WORD display_xres, display_yres;
			      /* doi cinsinden cozunurluk */
       BYTE palette[48];  /* eger sigarsa palet verisi(256 renk icin degil */
       BYTE reserved;
       BYTE nplanes;          /* verideki bit yuzeyi(bit plane) sayisi */
       WORD bytesperline;     /* sikistirilmamis veride byte/satir */
       WORD palletteinfo;
       BYTE reserved2[58];
    } PCX_HDR;

long tambelbuy;
BYTE palet[256][3];

void loadpalette(int fp)  // Palet datasi yukler
{
BYTE *index;
long position;
int f,g;
position=(filelength(fp)-768);   // dosyada palet datasinin yerini bulur

lseek(fp,position,SEEK_SET);
_read(fp,palet,768);            // dosyadan okur
index=palet;
outportb(0x3c6,0x0ff);          // direk VGA kartinin portlarina yazar
for(f=0;f<256;f++){
   outportb(0x03c8,(BYTE)(f));
   for(g=0;g<3;g++){
      outportb(0x03c9,(BYTE)((*index++))>>2);
      }
   }
}

void putdot(unsigned x,unsigned y,BYTE color)
{                        // BIOS interrupt'i kullanarak nokta koyar
	                        // Yavastir ama her karta ve moda uyumludur
union REGS regs;
regs.h.ah=0x0c;
regs.h.al=(BYTE)(color);
regs.x.bx=0;
regs.x.cx=x;
regs.x.dx=y;
int86(0x10,&regs,&regs);
}

void printcolorface(char *fil,unsigned firstx,unsigned firsty)
{
int fp,f;
int siz;
unsigned xpos=firstx,ypos=firsty;
long g,s;
char *linestart=NULL;
BYTE renk,asilrenk;
PCX_HDR hdr;
BYTE *buffer;
BYTE *indexer;
unsigned nofbytes;

siz=sizeof(PCX_HDR);

 if ((fp = open(fil, O_RDONLY)) == NULL){  // dosya acilir
     printf("\nCannot open file %s",fil);
     }
     else
     {
     tambelbuy=filelength(fp);
     read(fp,&hdr,siz);                    // veriler okunur
     buffer=malloc(tambelbuy+1);           // hafiza ayrilir
     indexer=buffer;
     loadpalette(fp);                      // palet yuklenir
     lseek(fp,128,SEEK_SET);
     nofbytes=(unsigned)(_read(fp,buffer,tambelbuy));
     if(hdr.pcx_id==0x0A){                  // dosya PCX mi?

			 g=filelength(fp)-128-768;
			 while(g>0)                             // evetse devam
			  {
			 renk=*indexer++;                       // byte alinir
			 g--;
			 if((renk&0xc0)!=0xc0)                  // maskelenir
			     {
			      putdot(xpos,ypos,renk);           // maskeden gecerse yani
                                           // tekrarlanan renk degilse basilir
			      xpos++;
			     if((xpos)>hdr.lorightx+firstx) { xpos=firstx;  // ekran sonu kontrolu
							      ypos++;
							    }

			     }
			 else
			     {
			     asilrenk=*indexer++;       // maskeden gecmezse tekrar sayisidir
                                   // asil renk okunur
			     g--;
			     renk=renk&0x3f;            // renk maskelenip tekrar sayisi cikar
			     for(f=0;f<renk;f++)
				{
			     putdot(xpos,ypos,asilrenk);  // tekrar sayisi kadar asilrenk basilir
			     xpos++;
			     if((xpos)>hdr.lorightx+firstx) { xpos=firstx;
							      ypos++;
							    }
				}
			     }
			  }
			 }
     else printf("\n%s PCX degil !",fil); // PCX degilse mesaj
    }
    close(fp);                        // dosyalar kapatilir
    free(buffer);                     // hafiza birakilir
}

void setgrmode(BYTE mod)              // ekran modu ayarlar
{                                     // BIOS int 10 ile
union REGS regs;
regs.h.ah=0x00;
regs.h.al=mod;
int86(0x10,&regs,&regs);
}

void cyclepalette(int basla, int bit)  // Palet animasyonu yapar
{
BYTE *index; // palet datasi indexi
BYTE dum[3]; // donecek palet elemani icin bos degisken

int f,g;

do
 {
 index=palet; // index duzeltilir
 delay(10);   // kisa bir sure bekleme(animasyon anlasilsin diye)
 movmem(&palet[bit][0],&dum[0],3); // paletin son rengi bos degiskene saklanir
 movmem(&palet[basla][0],&palet[basla+1][0],(bit-basla)*3); // ara renkler birer ileri alinir
 movmem(&dum[0],&palet[basla][0],3); //son renk basa koyularak dondurme islemi tamamlanir

outportb(0x3c6,0x0ff);          // direk VGA kartinin portlarina yazar
for(f=0;f<256;f++){
   outportb(0x03c8,(BYTE)(f));
   for(g=0;g<3;g++){
      outportb(0x03c9,(BYTE)((*index++))>>2);
      }
   }
 } while(!kbhit()); // tusa basilana kadar renk dondurme islemi devam eder

}

void main(void)
{
 char di[255]="palet.pcx\0";

 setgrmode(0x13);                      // 320x200x256 mod ayarlanir
 printcolorface(di,0,0);               // Dosya ekrana basilir
 cyclepalette(16,80);                  // Palet animasyonu yapilir
 setgrmode(0x3);                       // text moduna donulur
}
